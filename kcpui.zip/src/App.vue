<template>
	<div id="app">
		<!--
			[component 네이밍]
			template 으로 사용하는 덩어리 개념: PascalCase
			template 내 사용하는 요소 개념: kebab-case
		-->

		<!-- header -->
		<!-- 각각의 페이지에서 연결 -->
		<!-- <TheHeader></TheHeader> -->
		<!-- //header -->

		<!-- router -->
		<router-view></router-view>
		<!-- //router -->

		<!-- footer -->
		<!-- 각각의 페이지에서 연결 -->
		<!-- <TheFooter></TheFooter> -->
		<!-- //footer -->
	</div>
</template>

<script>
	export default {
		name: 'App',
	}
</script>

<style>
	/* #app{} */
</style>
