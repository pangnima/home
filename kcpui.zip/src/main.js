import '@babel/polyfill'; // vue-fragment ie 대응 추가
import Vue from 'vue';

// plugins
import Fragment from 'vue-fragment'

// css
import '@/assets/css/reset.css';

// start
import App from '@/App.vue';

// router
import router from '@/router';

// used & options
Vue.use(Fragment.Plugin);
Vue.config.productionTip = false;

// component
/*
	내장 또는 예약된 HTML 요소를 구성 요소 이름으로 사용했을때 오류로 교체
	(Do not use built-in or reserved HTML elements as component id: header)
	: Header -> TheHeader (명칭 앞에 the 붙임)
*/
import TheHeader from '@/components/layout/TheHeader';
import TheFooter from '@/components/layout/TheFooter';
import Container from '@/components/layout/Container';

Vue.component('TheHeader', TheHeader);
Vue.component('TheFooter', TheFooter);
Vue.component('Container', Container);

new Vue({
	router,
	render: h => h(App),
}).$mount('#app')
