<template>
	<div>
		<div class="list-box">
			<ul>
				<!-- <li v-for="items in this.$attrs.searchArray" :key="items.index">
					<text-highlight :queries=queries>{{items}}</text-highlight>
				</li> -->
				<li v-for="items in classList" :key="items.index">{{items}}</li>
			</ul>
		</div>
		<div class="pagenation">
			<a href="#"><img src="@/assets/images/markup/btn_double_arrow_left.svg" alt="맨앞으로 버튼"></a>
			<a href="#"><img src="@/assets/images/markup/btn_arrow_left.svg" alt="한페이지 앞으로"></a>
			<ul>
				<li class="active">1</li>
				<li>2</li>
				<li>3</li>
				<li>4</li>
				<li>5</li>
				<li>6</li>
				<li>7</li>
				<li>8</li>
				<li>9</li>
				<li>10</li>
			</ul>
			<a href="#"><img src="@/assets/images/markup/btn_arrow_right.svg" alt="한페이지 뒤로"></a>
			<a href="#"><img src="@/assets/images/markup/btn_double_arrow_right.svg" alt="맨뒤로"></a>
		</div>
	</div>
</template>
<script>
import Vue from 'vue';
import TextHighlight from 'vue-text-highlight';
Vue.component('text-highlight', TextHighlight);
export default {
	name: 'listBox',
	porops:["inputText","queries"],
	data(){
		return{
			queries: [],
			// description: 'Tropical birds scattered as Drake veered the Jeep',
			classList : [				
				".abp_ob_exist",
				".AdFrameLB",
				".LeaderBoardAd",
				".above_miniscore_ad",
				".ad-lead",
				".ad-skyscraper2",
				".ad200x60",
				".adBrandpanel",
				".ad_bn",
				".ad_no_border",
				".adblock_primary",
				".admods",
				".ads-sidebar-boxad",
				".ads_before",
				".adsense300",
				".adtxtlinks",
				".advbanner_970x90"]
		}
	}
}
</script>

<style scoped>
	.list-box{margin-top:15px;border-top:solid 2px #212121;}
	.list-box ul{display:flex;padding:20px 15px;font-size:14px;flex-wrap:wrap;}
	.list-box ul li{width:25%;padding:10px 15px;border-left:solid 1px #e1e1e1;box-sizing:border-box;}
	.list-box ul li:nth-child(4n+1){padding-left:0;border-left:0;}
	.pagenation{display:flex;margin-top:50px;align-items:center;justify-content:center;}
	.pagenation a{margin:0 2px;}
	.pagenation ul{display:flex;padding:0 7px;font-size:14px;}
	.pagenation ul li{padding:0 7px;color:#999;cursor:pointer;}
	.pagenation ul li.active{color:#212121;font-weight:bold;}
</style>