<template>
	<fragment>
		<!-- header -->
		<TheHeader :class="'type-1'"></TheHeader>
		<!-- //header -->

		<!-- 컨텐츠 -->
		<main>
			<MainVisual :locations=locations>
				<slot>
					<!-- 텍스트 -->
					<div class="visual-txt">
						<Typography :as="'h2'">애드블록 차단 소스</Typography>
						<Typography>
							사용자가 광고 차단 서비스인 애드블록(Adblock)을 설치했을 시 일부 UI가 미 노출될 수 있습니다.<br>
							차단될 우려가 있는 광고 관련 소스 사용은 삼가주시기 바랍니다.
						</Typography>
					</div>
				</slot>
			</MainVisual>
			<Container>
				<div class="consult-list">
					<Typography :as="'h2'" class="title">개발팀 협의사항</Typography>
					<Typography>· 마크업 또는 개발 작업 시 ad, ads, adv, advert, spon, sponsors, sponsor을 포함한 소스 사용 불가합니다.</Typography>
					<Typography>· 사용자의 추가로 인해 업데이트되는 광고 영역 구조를 모두 고려는 불가하여, 가장 많이 차단되는 표기 기준으로 협의 되었습니다.</Typography>
				</div>
			</Container>

			<Container>
				<div class="source-list">
					<Typography :as="'h2'">주로 사용되는 소스</Typography>
					<ol>
						<li><div>ad, ads (ex. advert, adv)</div> <strong>883ea</strong></li>
						<li><div>spon (ex. sponsors, sponsor)</div> <strong>26ea</strong></li>
						<li><div>그 외 etc</div> <strong>88ea</strong></li>
					</ol>
				</div>
			</Container>

			<Container>
				<div>
					<typography :as="'h5'" padding="107px 0 30px">애드블록 소스 분석 <span>(2018.09.19)</span></typography>
					<div class="search-box">
						<div class="tab">
							<router-link to="/markup/adblock/class" tag="button">class 548개</router-link>
							<router-link to="/markup/adblock/id"  tag="button">id 450개</router-link>
						</div>
						<div class="search-input">
							<input type="text" placeholder="" id="search">
							<label for="search">검색</label>
							<span></span>
						</div>
						<a href="#" class="btn-download">애드블록 차단 소스 다운로드</a>
					</div>
					<router-view></router-view>
				</div>
			</Container>
		</main>
		<!-- //컨텐츠 -->

		<!-- Footer -->
		<TheFooter></TheFooter>
		<!-- //Footer -->
	</fragment>
</template>

<script>
	import MainVisual from '@/pages/Markup/mainVisual.vue'
	export default {
		name:"adblock",
		components: {MainVisual},
		data(){
			return {
				inputText:"test",
				locations: [
				// name: 라우터 네임드
					{id: 1, name: 'markup', text: this.$route.meta.location.markup},
					{id: 2, name: 'markup', text: this.$route.meta.location.markupadblock}
				],
			}
		},
		methods: {
			// searchs : function(e){
			// 	this.searchArray = [];
			// 	let result = this.list.map( text => {
			// 		if(text.indexOf(e) > 0){
			// 			this.searchArray.push(text);
			// 		}
			// 	})
			// 	console.log(this.searchArray)
			// 	return result;
			// }
		}
	}
</script>

<style scoped>
main{padding-top:0;}
.consult-list{padding-top:60px;}
.consult-list h2{color:#212121;font-size:22px;}
.consult-list p{margin-top:10px;font-size:18px;}
.source-list{padding-top:60px;}
.source-list h2{color:#212121;font-size:22px;}
.source-list ol{margin-top:30px;}
.source-list ol li{display:flex;margin-top:25px;align-items:center;}
.source-list ol li div{height:50px;padding:0 30px;border-radius:30px;color:#fff;line-height:50px;}
.source-list ol li strong{margin-left:15px;}
.source-list ol li:first-child div{background:#00c0f3;width:752px;}
.source-list ol li:nth-child(2) div{background:#262626;width:332px;}
.source-list ol li:last-child div{background:#e1e1e1;width:456px;color:#212121;}
.search-box{display:flex;align-items:center;}
.search-box .tab button{background:#f2f2f2;height:60px;padding:0 60px;border:0;color:#7c7c7c;line-height:60px;font-size:18px;cursor:pointer;;}
.search-box .tab .router-link-active{background:#141414;color:#fff;}
.search-box .search-input{display:flex;position:relative;margin-left:auto;align-items:center;;}
.search-box .search-input span{position:absolute;left:0;bottom:0;background-color:#000;width:0;height:2px;transition:width .5s;}
.search-box .search-input input:focus ~ span{width:100%;}
.search-box .search-input input{height:50px;border:0;font-size:18px;}
.search-box .search-input label{display:block;background:url("~@/assets/images/markup/icon_search.svg") 0 0 no-repeat;width:28px;height:28px;margin-left:20px;font:0/0 a;;}
.search-box .btn-download{background:#000;height:50px;margin-left:20px;padding:0 40px;color:#fff;line-height:50px;text-align:center;;}
</style>