<template>
	<div>마크업 애드블록

		<div class="tab">
			<router-link to="/markup/adblock/class">탭버튼(class)</router-link>/
			<router-link to="/markup/adblock/id">탭버튼(id)</router-link>
		</div>

		<router-view></router-view>
	</div>
</template>

<style scoped>
	.tab{margin-bottom:50px;}
	.tab .router-link-exact-active{color:red;}
	.tab .router-link-active{text-decoration:underline;}
</style>