<template>
	<button type="button"><span>
		<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
			<g stroke="#000" fill="none" fill-rule="evenodd">
				<circle fill="#FFF" cx="25" cy="25" r="24.5"/>
				<path stroke-width="1.5" d="m19 28 6-6 6 6"/>
			</g>
		</svg>
	</span></button>
</template>

<script>
export default {
	name : 'DownLoadBtn',
}
</script>