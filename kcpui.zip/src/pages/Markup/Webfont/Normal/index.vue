<template>
	<div>
		<div class="font-info">
			<Typography :as="'p'" :type="'p2'">· 한글 2428개</Typography>
			<Typography :as="'p'" :type="'p2'">· 특수문자 ×÷※ⓒ~!@#$%^&*()_-+=| {[]}"':;?/>.&lt;,'"「」★ ☎ ○ ◎ ● · </Typography>
			<Typography :as="'p'" :type="'p2'">· 숫자 1 2 3 4 5 6 7 8 9 0 ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮</Typography>
			<Typography :as="'p'" :type="'p2'">· 통화기호 ￦＄￥</Typography>
		</div>

		<div class="font-list">
			<ul>
				<li v-for="item in fontList" :key=item.id class="font-list-item" :class="{active : isToggle}">
					<div class="font-detail">
						<Typography :as="'h2'" fontSize="62px" :style="{'font-family':item.fontNameClass}">{{item.fontName}}</Typography>
						<dl>
							<dt>언어</dt>
							<dd>{{item.fontLangs}}</dd>
							<dt>개발사</dt>
							<dd>{{item.fontDev}}</dd>
							<dt>폰트 굵기</dt>
							<dd>{{item.fontWeight}}</dd>
						</dl>
						<button type="button" v-on:click="slideToggle"><span>
							<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
								<g stroke="#000" fill="none" fill-rule="evenodd">
									<circle fill="#FFF" cx="25" cy="25" r="24.5"/>
									<path stroke-width="1.5" d="m19 28 6-6 6 6"/>
								</g>
							</svg>
						</span></button>
					</div>

					<ul class="font-preview">
						<li v-for="(previewItem, index) in item.fontPerview" :key=previewItem.id :style="{'font-family':item.fontPerviewStyle[index]}">{{previewItem}}</li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	// import DownLoadBtn from '@/pages/Markup/Webfont/btnDownload.vue';
	export default {
		name :"test",
		// components:{ DownLoadBtn},
		data() {
			return{
				isToggle:false,
				fontList : [
					{
						id:1,
						fontName:'나눔고딕',
						fontNameClass:'NanumGothic',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumGothic Light','Nanum Gothic','Nanum Gothic Bold','Nanum Gothic ExtraBold'],
						fontPerviewStyle:['NanumGothicLight','NanumGothic','NanumGothicBold','NanumGothicExtraBold'],
					},
					{
						id:2,
						fontName:'나눔바른고딕',
						fontNameClass:'NanumBarunGothic',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumBarun Gothic Ultra Light','NanumBarunGothicLight','NanumBarunGothic','NanumBarunGothicBold'],
						fontPerviewStyle:['NanumBarunGothicUltraLight','NanumBarunGothicLight','NanumBarunGothic','NanumBarunGothicBold'],
					},
					{
						id:3,
						fontName:'나눔명조',
						fontNameClass:'NanumMyeongjo',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumMyeongjo','NanumMyeongjo Bold','NanumMyeongjo ExtraBold'],
						fontPerviewStyle:['NanumMyeongjo','NanumMyeongjoBold','NanumMyeongjoExtraBold'],
					},
					{
						id:4,
						fontName:'나눔손글씨펜체',
						fontNameClass:'NanumPen',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumPen'],
						fontPerviewStyle:['NanumPen'],
					},
					{
						id:5,
						fontName:'나눔손글씨붓체',
						fontNameClass:'NanumBrush',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumBrush'],
						fontPerviewStyle:['NanumBrush'],
					},
					{
						id:6,
						fontName:'나눔바른펜',
						fontNameClass:'NanumBarunpenR',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumBarunpenR','NanumBarunpenB'],
						fontPerviewStyle:['NanumBarunpenR','NanumBarunpenB'],
					},
					{
						id:7,
						fontName:'나눔스퀘어',
						fontNameClass:'NanumSquareR',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'NAVER',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NanumSquareL','NanumSquareR','NanumSquareB','NanumSquareEB'],
						fontPerviewStyle:['NanumSquareL','NanumSquareR','NanumSquareB','NanumSquareEB'],
					},
					{
						id:8,
						fontName:'노토산스',
						fontNameClass:'NotoSansCJKkr-Regular',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'Google',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NotoSansCJKkr-Thin','NotoSansCJKkr-Light','NotoSansCJKkr-DemiLight','NotoSansCJKkr-Regular','NotoSansCJKkr-Medium','NotoSansCJKkr-Bold','NotoSansCJKkr-Black'],
						fontPerviewStyle:['NotoSansCJKkr-Thin','NotoSansCJKkr-Light','NotoSansCJKkr-DemiLight','NotoSansCJKkr-Regular','NotoSansCJKkr-Medium','NotoSansCJKkr-Bold','NotoSansCJKkr-Black'],
					},
					{
						id:9,
						fontName:'노토세리프',
						fontNameClass:'NotoSansCJKkr-Regular',
						fontLangs:'한글, 영문, 숫자, 부호',
						fontDev :'Google',
						fontWeight:'Light, Regular, Bold, ExtraBold',
						fontPerview:['NotoSerifCJKkr-ExtraLight','NotoSerifCJKkr-Light','NotoSerifCJKkr-Regular','NotoSansCJKkr-Regular','NotoSerifCJKkr-Medium','NotoSerifCJKkr-SemiBold','NotoSerifCJKkr-Bold','NotoSerifCJKkr-Black'],
						fontPerviewStyle:['NotoSerifCJKkr-ExtraLight','NotoSerifCJKkr-Light','NotoSerifCJKkr-Regular','NotoSansCJKkr-Regular','NotoSerifCJKkr-Medium','NotoSerifCJKkr-SemiBold','NotoSerifCJKkr-Bold','NotoSerifCJKkr-Black'],
					}
				],
			}
		},
		methods :{
			slideToggle : function(){
				// const targetId = event.currentTarget.id;
				console.log(this.index); // returns 'foo'
				// console.log(this)
				// if ( this.isToggle ){
				// 	this.isToggle = false;
				// } else {
				// 	this.isToggle = true;	
				// }
			}
		}
	}
</script>

<style scoped>
.font-info{margin-top:20px;padding-top:10px;border-top:solid 2px #212121;}
.font-info p{padding-top:10px;}
.font-list{padding-top:40px;}
.font-list .font-list-item{display:flex;align-items:center;flex-wrap:wrap;}
.font-list .font-detail{display:flex;width:100%;min-height:160px;align-items:center;flex:0 0 100%;}
.font-list .font-detail dl{display:flex;margin-left:auto;}
.font-list .font-detail dl dt{margin-left:30px;color:#7c7c7c;}
.font-list .font-detail dl dd{margin-left:10px;color:#212121;}
.font-list .font-detail dl + button{margin-left:20px;}
.font-list .font-detail button{background:transparent;padding:0;border:0;cursor:pointer;vertical-align:top;}
.font-list .font-detail button span{position:relative;}
.font-list .font-detail button svg{display:block;}
.font-preview{overflow:hidden;height:1px;border-top:solid 1px #ececec;transition:height .5s;flex:0 0 100%;}
.font-preview li{display:flex;background:#f7f7f7;height:85px;padding:0 30px;border-bottom:solid 1px #e1e1e1;font-size:24px;align-items:center;justify-content:space-between;}
.font-preview li a{font-family:NotoSansCJKkr;font-size:14px;}
.font-list-item.active .font-preview{height:inherit;}
@font-face{font-family:"NanumGothicLight";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumGothicLight.woff") format("woff");}
@font-face{font-family:"NanumGothic";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumGothic.woff") format("woff");}
@font-face{font-family:"NanumGothicBold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumGothicBold.woff") format("woff");}
@font-face{font-family:"NanumGothicExtraBold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumGothicExtraBold.woff") format("woff");}
@font-face{font-family:"NanumBarunGothicUltraLight";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunGothicUltraLight.woff") format("woff");}
@font-face{font-family:"NanumBarunGothicLight";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunGothicLight.woff") format("woff");}
@font-face{font-family:"NanumBarunGothic";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunGothic.woff") format("woff");}
@font-face{font-family:"NanumBarunGothicBold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunGothicBold.woff") format("woff");}
@font-face{font-family:"NanumMyeongjo";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumMyeongjo.woff") format("woff");}
@font-face{font-family:"NanumMyeongjoBold";font-style:normal;font-weight:700;src:url("https://cdn.kcp.co.kr/font_web/NanumMyeongjoBold.woff") format("woff");}
@font-face{font-family:"NanumMyeongjoExtraBold";font-style:normal;font-weight:900;src:url("https://cdn.kcp.co.kr/font_web/NanumMyeongjoExtraBold.woff") format("woff");}
@font-face{font-family:"NanumPen";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumPen.woff") format("woff");}
@font-face{font-family:"NanumBrush";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBrush.woff") format("woff");}
@font-face{font-family:"NanumBarunpenR";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunpenR.woff") format("woff");}
@font-face{font-family:"NanumBarunpenB";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumBarunpenB.woff") format("woff");}
@font-face{font-family:"NanumSquareL";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumSquareL.woff") format("woff");}
@font-face{font-family:"NanumSquareR";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumSquareR.woff") format("woff");}
@font-face{font-family:"NanumSquareB";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumSquareB.woff") format("woff");}
@font-face{font-family:"NanumSquareEB";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NanumSquareEB.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Thin";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Thin.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Light";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Light.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-DemiLight";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-DemiLight.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Regular";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Regular.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Medium";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Medium.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Bold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Bold.woff") format("woff");}
@font-face{font-family:"NotoSansCJKkr-Black";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSansCJKkr-Black.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-ExtraLight";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-ExtraLight.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-Light";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-Light.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-Regular";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-Regular.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-Medium";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-Medium.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-SemiBold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-SemiBold.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-Bold";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-Bold.woff") format("woff");}
@font-face{font-family:"NotoSerifCJKkr-Black";font-style:normal;src:url("https://cdn.kcp.co.kr/font_web/NotoSerifCJKkr-Black.woff") format("woff");}


</style>