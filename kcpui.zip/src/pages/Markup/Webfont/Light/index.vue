<template>
	<div>
		<Typography>· 한글 2428개</Typography>
		<Typography>· 특수문자 ×÷※ⓒ~!@#$%^&*()_-+=| {[]}"':;?/>.&lt;,'"「」★ ☎ ○ ◎ ● · </Typography>
		<Typography>· 숫자 1 2 3 4 5 6 7 8 9 0 ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮</Typography>
		<Typography>· 통화기호 ￦＄￥</Typography>
	</div>
</template>