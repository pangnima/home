<template>
	<fragment>
		<!-- header -->
		<TheHeader :class="'type-1'"></TheHeader>
		<!-- //header -->

		<!-- 컨텐츠 -->
		<main>
			<MainVisual :locations=locations>
				<slot>
					<div class="visual-txt">
						<Typography :as="'h2'">NHN KCP내 웹 서비스의 디자인 폰트 사용 시<br/>경량화된 디자인 폰트를 사용합니다.</Typography>
						<Typography>
							경량화된 디자인 폰트는 UI 팀에서 무료 서체를 재조합하여 만든 폰트로 <span>외부 배포 불가합니다.</span><br/>
							경량화 폰트는 웹용과 결제창(경량 고도화) 폰트 두 가지로 나뉘며, 사용성을 고려하여 선택 바랍니다. 
						</Typography>
					</div>
				</slot>
			</MainVisual>

			<Container>
				<div class="consult-list">
					<Typography :as="'h2'" class="title">작업 시 유의사항</Typography>
					<Typography>· 모바일 폰트 : 사용자 설정 폰트 및 데이터 이슈로 인해 디자인 폰트 사용하지 않음</Typography>
					<Typography>· 폰트 포맷 : 크로스 브라우징 고려하여 W3C 권고안 woff 포맷 한가지로만 대응</Typography>
					<Typography>· 경량화 시 사용 문자 : 영문 “KS X 1001” 기반의 한글, 키보드에 있는 숫자와 부호만 적용 (* 일부 예외)</Typography>
					<Typography>· CSS font-family 설정 : 웹폰트, 시스템 폰트 순으로 설정</Typography>
				</div>
			</Container>

			<Container>
				<div>
					<div class="search-box">
						<div class="tab">
							<router-link to="/markup/webfont/normal" tag="button">일반 웹 사이트 버전 (일반)</router-link>
							<router-link to="/markup/webfont/light"  tag="button">결제창 버전 (경량 고도화)</router-link>
						</div>
					</div>
					
					<router-view></router-view>
				</div>
			</Container>
		</main>
		<!-- //컨텐츠 -->

		<!-- Footer -->
		<TheFooter></TheFooter>
		<!-- //Footer -->
	</fragment>
	<!-- <div>마크업 웹폰트

		<div class="tab">
			<router-link to="/markup/webfont/normal">탭버튼(일반)</router-link>/
			<router-link to="/markup/webfont/light">탭버튼(경량)</router-link>
		</div>

		<router-view></router-view>
	</div> -->
</template>
<script>
	import MainVisual from '@/pages/Markup/mainVisual.vue';
	export default {
		name:"webfonts",
		components: {
			MainVisual,
		},
		data(){
			return {
				inputText:"test",
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'markup', text: this.$route.meta.location.markup},
					{id: 2, name: 'markup', text: this.$route.meta.location.markupwebfont}
				],
			}
		},
		methods: {
			// searchs : function(e){
			// 	this.searchArray = [];
			// 	let result = this.list.map( text => {
			// 		if(text.indexOf(e) > 0){
			// 			this.searchArray.push(text);
			// 		}
			// 	})
			// 	console.log(this.searchArray)
			// 	return result;
			// }
		}
	}
</script>
<style scoped>
	main{padding-top:0;}
	.main-visual{background:#212121 url("~@/assets/images/markup/webfont/top_visual.png") right 0 no-repeat; background-size: contain;}
	.consult-list{padding-top:60px;}
	.consult-list h2{color:#212121;font-size:22px;}
	.consult-list p{margin-top:10px;font-size:18px;}

	.search-box{display:flex;align-items:center; padding-top:60px;}
	.search-box .tab button{background:#f2f2f2;height:60px;padding:0 60px;border:0;color:#7c7c7c;line-height:60px;font-size:18px;cursor:pointer;;}
	.search-box .tab .router-link-active{background:#141414;color:#fff;}
	.search-box .search-input{display:flex;position:relative;margin-left:auto;align-items:center;;}
	.search-box .search-input span{position:absolute;left:0;bottom:0;background-color:#000;width:0;height:2px;transition:width .5s;}
	.search-box .search-input input:focus ~ span{width:100%;}
	.search-box .search-input input{height:50px;border:0;font-size:18px;}
	.search-box .search-input label{display:block;background:url("~@/assets/images/markup/icon_search.svg") 0 0 no-repeat;width:28px;height:28px;margin-left:20px;font:0/0 a;;}
	.search-box .btn-download{background:#000;height:50px;margin-left:20px;padding:0 40px;color:#fff;line-height:50px;text-align:center;;}


</style>