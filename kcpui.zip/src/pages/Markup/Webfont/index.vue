<template>
	<div>마크업 웹폰트

		<div class="tab">
			<router-link to="/markup/webfont/normal">탭버튼(일반)</router-link>/
			<router-link to="/markup/webfont/light">탭버튼(경량)</router-link>
		</div>

		<router-view></router-view>
	</div>
</template>

<style scoped>
	.tab{margin-bottom:50px;}
	.tab .router-link-exact-active{color:red;}
	.tab .router-link-active{text-decoration:underline;}
</style>