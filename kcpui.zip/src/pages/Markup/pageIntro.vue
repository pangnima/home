<template>
	<section class="page-intro">
		<Typography :as="'h3'">{{title}}</Typography>
		<div class="desc">
			<Typography :as="'p'" v-html="txt">
			</Typography>
		</div>
		<div class="btn-container">
			<a href="#none" class="btn-download">{{ btnText }}</a>
		</div>
		<slot></slot>
	</section>
</template>

<script>
export default {
	name: 'PageIntro',
	props: ['title','txt','btnText'],
}
</script>

<style scoped>
	.page-intro{padding-bottom:60px;}
	.page-intro .desc{margin-top:20px;line-height:28px;font-size:16px;}
	.page-intro .desc >>> span{display:block;color:#e02020;}
	.page-intro .sub-desc{margin-top:100px;line-height:28px;font-size:16px;}
	.page-intro .sub-desc h3{font-size:22px;}
	.page-intro .sub-desc p{margin-top:12px;}
	.page-intro .sub-desc >>> strong{display:block;}
	.page-intro .btn-container{margin-top:40px;}
	.btn-download{display:inline-block;background:#000;padding:12px 40px 14px;color:#fff;font-size:16px;}
</style>