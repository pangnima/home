<template>
	<section class="main-visual">
		<Container>
			<Location v-bind:locations="locations" :key="locations.id"></Location>
		</Container>
		<Container>
			<slot></slot>
		</Container>
	</section>
</template>

<script>
export default {
	name: 'MainVisual',
	props:['locations'],
	data(){
		return {}
	}
}
</script>

<style scoped>
.main-visual{display:flex;background:#262626 url("../../assets/images/markup/top_visual.png") 0 0 no-repeat;background-size:100% 100%;height:800px;flex-direction:column;justify-content:space-between;}
.main-visual .container{width:100%;}
.main-visual >>> .location{padding-top:100px;}
.main-visual >>> .location .link{color:#fff;}
.main-visual >>> .location .icon-arrow{opacity:.6;stroke:#fff;;}
.main-visual >>> .visual-txt{padding-bottom:62px;}
.main-visual >>> .visual-txt h2{padding-bottom:21px;color:#fff;font-size:32px;}
.main-visual >>> .visual-txt p{color:#999;font-size:18px;}
.main-visual >>> .visual-txt p span {color:#00c0f3}
</style>