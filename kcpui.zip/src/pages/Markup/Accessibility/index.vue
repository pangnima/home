<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->
		<main>
			<Container>
				<!-- 로케이션 -->
				<Location :locations="locations"></Location>
				<!-- // 로케이션 -->

				<PageIntroArea 
					:title="'웹 결제창 접근성 가이드'"
					:btnText="'접근성  가이드 보기'"
					:txt="`
						접근성 가이드는 NHN KCP 웹 결제창 적용 사례를 기분으로 작성되었으며, 상세한 내용은 다운로드 후 확인 바랍니다.<br>
						<span>해당 가이드는 대외비입니다.</span>
					`"
				>
				</PageIntroArea>
			</Container>
			
			<!-- bind 기준 자식="부모" -->
			<ContentsBox :contentsList="accessibilityList"></ContentsBox>
		</main>

		<!-- Footer -->
		<TheFooter></TheFooter>
		<!-- //Footer -->
	</fragment>
</template>

<script>
	import PageIntroArea from '@/pages/Markup/pageIntro.vue'
	import ContentsBox from '@/pages/Markup/contentsBox';
	
	export default {
		components: {
			PageIntroArea,
			ContentsBox
		},
		data() {
			return {
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'markup', text: '마크업 시 참고'},
					{id: 2, name: 'markup', text: '마크업 가이드'}
				],
				accessibilityList:[
					{
						id:1,
						listTitle : "웹접근성이란",
						listItem : ["웹접근성 개요","디자인 체크리스트","개발 체크리스트"],
					},
					{ 
						id:2,
						listTitle: "센스리더기",
						listItem : ["기본설정","센스리더기 단축키"]
					},
					{ 
						id:3,
						listTitle: "기타 접근성 확인툴",
						listItem : ["Color Contrast Analyser","N-WAX"]
					},
					{ 
						id:4,
						listTitle: "마크업 매뉴얼",
						listItem : ["마크업 기본 매뉴얼","인풋박스 및 기타"]
					},
					{ 
						id:5,
						listTitle: "CSS 참고",
						listItem : ["CSS 스킨 컬러 수정 시"]
					},
					{ 
						id:6,
						listTitle: "접근성 미해결 이슈",
						listItem : ["체크박스 더블클릭 등"]
					},
					{ 
						id:7,
						listTitle: "개발 확인 시 자주 발행하는 이슈",
						listItem : ["보안 프로그램 설치 등"]
					},
					{ 
						id:8,
						listTitle: "테스트 정보",
						listItem : ["테스트 시 주의사항 1","테스트 시 주의사항 2"]
					}
				]
			}
		}
	}
</script>

<style scoped>
	.navigation{display:flex; padding-top:20px;}
	.navigation li{display:flex; color:#212121; opacity:.6; align-items:center;}
	.navigation li::after{content:""; display:block; background:url(../../../assets/images/icon_arrow.png) 0 0 no-repeat; background-size:100% 100%; width:7px; height:12px; margin:0 8px;}
	.navigation li:last-child{opacity:1;}
	.navigation li:last-child::after{display:none;}
</style>