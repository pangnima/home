<template>
	<fragment>
		<!-- header -->
		<TheHeader :theme="'white'"></TheHeader>
		<!-- //header -->

		<main>
			<Container>
				<!-- 로케이션 -->
				<Location :locations="locations"></Location>
				<!-- // 로케이션 -->

				<!-- 페이지 소개 -->
				<PageIntroArea 
					:title="'마크업 가이드'"
					:btnText="'마크업 가이드 다운로드'"
					:txt="`
							이 가이드는 NHN KCP UI 팀에서 진행되는 마크업 방법에 대해 설명합니다.<br>
							<br>
							마크업 가이드는 NHN KCP 내 프런트-엔드 개발 협업과 팀 내 운영 효율성을 높이기 위한<br>
							규칙(Regulation)으로 최소한의 규칙만 표기하였습니다.<br>
							마크업은 디자인, 브라우저, 스크립트, 성능, 접근성 등과 긴밀한 관계가 있으므로 일관성 있게 코드를 작성하여 리스크를 최소화합니다.<br>
							<span>해당 가이드는 외부 배포 불가합니다.</span>`">
					<slot>
						<div class="sub-desc">
							<Typography :as="'h5'">문의처</Typography>
							<Typography>
								이 문서의 내용에 오류가 있거나 내용과 관련한 문의사항은 아래 연락처로 문의 바랍니다.
								<strong>NHN KCP UI팀 :<a href="mailto:design@kcp.co.kr"> design@kcp.co.kr</a></strong>
							</Typography>
						</div>
					</slot>
				</PageIntroArea>
				<!-- // 페이지 소개 -->
			</Container>

			<!-- bind 기준 자식="부모" -->
			<ContentsBox :contentsList="markupList"></ContentsBox>
		</main>

		<!-- Footer -->
		<TheFooter></TheFooter>
		<!-- //Footer -->
	</fragment>
</template>

<script>
	import PageIntroArea from '@/pages/Markup/pageIntro.vue';
	import ContentsBox from '@/pages/Markup/contentsBox';

	export default {
		components: {
			PageIntroArea,
			ContentsBox
		},
		data() {
			return {
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'markup', text: '마크업 시 참고'},
					{id: 2, name: 'markup', text: '마크업 가이드'}
				],
				markupList:[
					{
						id:1,
						listTitle : "마크업 Guide 개요",
						listItem : [],
					},
					{ 
						id:2,
						listTitle: "기본 규칙",
						listItem : ["DTD 및 인코딩 선언","기본 코드 레이아웃","들여쓰기","빈줄","따옴표", "문법", "주석","Font","CSS Reset"]
					},
					{ 
						id:3,
						listTitle: "속성 선언 순서",
						listItem : ["HTML","CSS"]
					},
					{ 
						id:4,
						listTitle: "폴더 구조",
						listItem : ["기본 규칙"]
					},
					{ 
						id:5,
						listTitle: "네임 규칙",
						listItem : ["기본 규칙","ID, Class 단어 규칙","이미지 단어 규칙"]
					},
					{ 
						id:6,
						listTitle: "Layout 설계",
						listItem : ["기본 Layout","표기"]
					},
					{ 
						id:7,
						listTitle: "CSS 작업 시 유의사항",
						listItem : ["기본 규칙","z-index","핵(hak)"]
					},
					{ 
						id:8,
						listTitle: "Script 작업 시 유의사항",
						listItem : ["기본 규칙"]
					}
				]
			}
		},
	}
</script>
<style scoped>
.markup-list{background:#f2f2f2;}
.markup-list .container{display:flex;padding-top:80px;padding-bottom:20px;flex-wrap:wrap;}
.markup-list .content-list{margin-left:auto;}
.markup-list .content-list > ul{display:flex;width:900px;margin-left:auto;counter-reset:chapter 0;flex:1;flex-wrap:wrap;}
.markup-list .content-list > ul > li:nth-child(3n+2){margin-right:40px;margin-left:40px;}
.markup-list .content-list > ul > li{width:230px;margin-bottom:60px;color:#101010;}
.markup-list .content-list > ul > li::before{content:"";content:"0" counter(chapter);display:block;padding-bottom:10px;border-bottom:solid 1px #000;font-size:16px;counter-increment:chapter;}
.markup-list .content-list > ul > li h3{margin-top:12px;font-size:22px;}
.markup-list .content-list > ul > li > ul{margin-top:20px;color:#535353;line-height:24px;font-size:14px;;}
</style>