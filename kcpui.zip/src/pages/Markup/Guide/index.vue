<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<Container>
			<ul class="navigation">
				<li>홈 테스트</li>
				<li>마크업 시 참고22323</li>
				<li>마크업 가이드</li>
			</ul>
		</Container>

		<Container>
			<section class="page-intro">
				<h2>마크업 가이드</h2>
				<div class="desc">
					<p>
						이 가이드는 NHN KCP UI 팀에서 진행되는 마크업 방법에 대해 설명합니다.<br>
						<br>
						마크업 가이드는 NHN KCP 내 프런트-엔드 개발 협업과 팀 내 운영 효율성을 높이기 위한
						규칙(Regulation)으로 최소한의 규칙만 표기하였습니다.
						마크업은 디자인, 브라우저, 스크립트, 성능, 접근성 등과 긴밀한 관계가 있으므로 일관성 있게 코드를 작성하여 리스크를 최소화합니다.	
						<span>해당 가이드는 외부 배포 불가합니다.</span>
					</p>
				</div>

				<div class="btn-container">
					<a href="#none" class="btn-download">마크업 가이드 다운로드</a>
				</div>

				<div class="sub-desc">
					<h3>문의처</h3>
					<p>
						이 문서의 내용에 오류가 있거나 내용과 관련한 문의사항은 아래 연락처로 문의 바랍니다.
						<strong>NHN KCP UI팀 :<a href="mailto:design@kcp.co.kr"> design@kcp.co.kr</a></strong>
					</p>
				</div>
			</section>
		</Container>

		<section class="markup-list">
			<Container>
				<h2>CONTENTS</h2>
				<div class="content-list">
					<ul>
						<li>
							<h3>마크업 Guide 개요</h3>
						</li>
						<li>
							<h3>기본 규칙</h3>
							<ul>
								<li>DTD 및 인코딩 선언</li>
								<li>기본 코드 레이아웃</li>
								<li>들여쓰기</li>
								<li>빈줄</li>
								<li>따옴표</li>
								<li>문법</li>
								<li>주석</li>
								<li>Font</li>
								<li>CSS Reset</li>
							</ul>
						</li>
						<li>
							<h3>속성 선언 순서</h3>
							<ul>
								<li>HTML</li>
								<li>CSS</li>
							</ul>
						</li>
						<li>
							<h3>폴더 구조</h3>
							<ul>
								<li>기본 규칙</li>
							</ul>
						</li>
						<li>
							<h3>네임 규칙</h3>
							<ul>
								<li>기본 규칙</li>
								<li>ID, Class 단어 규칙</li>
								<li>이미지 단어 규칙</li>
							</ul>
						</li>
						<li>
							<h3>Layout 설계</h3>
							<ul>
								<li>기본 Layout</li>
								<li>표기</li>
							</ul>
						</li>
							<li>
							<h3>CSS 작업 시 유의사항</h3>
							<ul>
								<li>기본 규칙</li>
								<li>z-index</li>
								<li>핵(hak)</li>
							</ul>
						</li>
						<li>
							<h3>Script 작업 시 유의사항</h3>
							<ul>
								<li>기본 규칙</li>
							</ul>
						</li>
					</ul>
				</div>
			</Container>
		</section>
	</fragment>
</template>

<style scoped>
.navigation{display:flex;padding-top:20px;}
.navigation li{display:flex;align-items:center;}
.navigation li::after{content:"";display:block;background:url(../../../assets/images/icon-arrow.png) 0 0 no-repeat;background-size:100% 100%;width:7px;height:12px;margin:0 8px;}
.navigation li:last-child::after{display:none;}
.page-intro{padding:80px 0 100px;}
.page-intro h2{font-size:32px;}
.page-intro .desc{margin-top:20px;line-height:28px;font-size:16px;}
.page-intro .desc span{display:block;color:#e02020;}
.page-intro .sub-desc{margin-top:100px;line-height:28px;font-size:16px;}
.page-intro .sub-desc h3{font-size:22px;}
.page-intro .sub-desc p{margin-top:12px;}
.page-intro .sub-desc strong{display:block;}
.page-intro .btn-container{margin-top:40px;}
.btn-download{display:inline-block;background:#000;padding:12px 40px 14px;color:#fff;font-size:16px;}
.markup-list{background:#f2f2f2;}
.markup-list .container{display:flex;padding-top:80px;padding-bottom:20px;flex-wrap:wrap;}
.content-list{flex:1;}
.markup-list h2{font-size:38px;}
.markup-list .content-list > ul{display:flex;counter-reset:chapter 0;flex:1;flex-wrap:wrap;justify-content:end;}
.markup-list .content-list > ul > li{width:230px;margin:0 40px;margin-bottom:60px;color:#101010;}
.markup-list .content-list > ul > li::before{content:"";content:"0" counter(chapter);display:block;padding-bottom:10px;border-bottom:solid 1px #000;font-size:16px;counter-increment:chapter;}
.markup-list .content-list > ul > li h3{margin-top:12px;font-size:22px;}
.markup-list .content-list > ul > li > ul{margin-top:20px;color:#535353;line-height:24px;;font-size:14px;}








</style>