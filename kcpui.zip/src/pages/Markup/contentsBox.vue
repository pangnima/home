<template>
	<section class="contents-box">
		<Container>
			<Typography :as="'h2'" fontSize="38px">CONTENTS</Typography>
			<div class="contents-list">
				<ul>
					<li v-for="items in contentsList" :key="items.id">
						<typography :as="'h3'">{{ items.listTitle }}</typography>
						<ul>
							<li v-for="items in items.listItem" :key="items.id">
								{{ items }}
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</Container>
	</section>
</template>

<script>
export default {
	name: 'contentsBox',
	props:['contentsList']
}
</script>

<style scoped>
	.contents-box{background:#f2f2f2;}
	.contents-box .container{display:flex;padding-top:80px;padding-bottom:20px;flex-wrap:wrap;}
	.contents-box h2{padding-bottom:60px;font-size:38px;flex:1;}
	.contents-box .contents-list{max-width:850px;}
	.contents-box .contents-list > ul{display:flex;margin-left:auto;counter-reset:chapter 0;flex:1;flex-wrap:wrap;}
	.contents-box .contents-list > ul > li:nth-child(3n+2){margin-right:80px;margin-left:80px;}
	.contents-box .contents-list > ul > li{width:230px;margin-bottom:60px;color:#101010;}
	.contents-box .contents-list > ul > li::before{content:"";content:"0" counter(chapter);display:block;padding-bottom:10px;border-bottom:solid 1px #000;font-size:16px;counter-increment:chapter;}
	.contents-box .contents-list > ul > li h3{margin-top:12px;font-size:22px;}
	.contents-box .contents-list > ul > li > ul{margin-top:20px;color:#535353;line-height:24px;font-size:14px;;}
</style>np