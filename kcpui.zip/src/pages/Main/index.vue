<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- Container -->
		<Container>
			<!-- <div>메인</div> -->
		</Container>
		<!-- //Container -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>