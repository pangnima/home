<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- Container -->
		<Container>
			<!-- Location -->
			<Location v-bind:locations="locations"></Location>
			<!-- white 테마 적용 -->
			<!-- <Location v-bind:locations="locations" v-bind:theme="'white'"></Location> -->
			<!-- //Location -->

			<!-- title-h3 -->
			<Typography :as="'h3'">
				NHN KCP의 디테일속 <br>
				숨은 기업 철학이 있는 CI 입니다. <br>
				다양한 매체에서 쉽게 활용 가능하도록 디자인되었습니다.
			</Typography>
			<!-- //title-h3 -->

			<!-- text-p2 -->
			<Typography :as="'p'" :type="'p2'">
				NHN KCP를 중심으로 뻗은 네모형상은  NHN KCP의 기술을 통해 안전한 결제, 편리한 생활의 조화로 이루어진 <br>
				금융 네트워크를 상징하며 나아가 최적화된 e-Life 공간을 구현하겠다는 의지가 깃들여져 있습니다.
			</Typography>
			<!-- //text-p2 -->

			<!-- title-h6 -->
			<Typography :as="'h6'">
				CI 다운로드
			</Typography>
			<!-- //title-h6 -->

			<!-- list-ci -->
			<list-ci v-bind:listcis="listcis">
				<!-- <fragment slot="title">
					NHN KCP CI
				</fragment>
				<fragment slot="txt">
					해당 가이드는 NHN과 협의가 이뤄진 CI 가이드로 외부 업체에서 <br>
					NHN KCP 로고 요청 시 사용 바랍니다. <br>
					가이드 외 디자인의 변경된 사용은 불가합니다. <br>
					<strong>파일 형식 : ai, jpg</strong>
				</fragment> -->
			</list-ci>
			<!-- //list-ci -->
		</Container>
		<!-- //Container -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
	import ListCi from "@/pages/Logo/ListCi";

	export default {
		name: 'LogoKcp',
		components: {ListCi},
		data: function(){
			return {
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'logo', text: '로고자료'},
					{id: 2, name: 'logokcp', text: 'NHN KCP'}
				],
				listcis: [
					{
						id: 1,
						imgs: [
							{id: 1, filename: 'logo/img_ci_1.png', alt: 'NHN KCP CI', mark: false},
						],
						title: 'NHN KCP CI',
						txt: '해당 가이드는 NHN과 협의가 이뤄진 CI 가이드로 외부 업체에서 <br>NHN KCP 로고 요청 시 사용 바랍니다. <br>가이드 외 디자인의 변경된 사용은 가합니다. <br><strong>파일 형식 : ai, jpg</strong>',
						btns: [
							{id: 1, text: '다운로드', link: 'https://cdn.kcp.co.kr/design/download/NHN%20KCP%20CI.zip'},
						]
					},
					{
						id: 2,
						imgs: [
							{id: 1, filename: 'logo/img_ci_2_1.png', alt: '문서 작업 용 CI', mark: '내부용'},
							{id: 2, filename: 'logo/img_ci_2_1.png', alt: '문서 작업 용 CI', mark: '내부용'},
							{id: 3, filename: 'logo/img_ci_2_1.png', alt: '문서 작업 용 CI', mark: '내부용'},
							{id: 4, filename: 'logo/img_ci_2_1.png', alt: '문서 작업 용 CI', mark: '내부용'},
						],
						title: '문서 작업 용 CI',
						txt: '문서 작업 시 로고 타입별(가로, 세로) / <br>컬러별로 배경 없는 이미지 필요 시 사용 바랍니다. <br><strong>파일 형식 : png</strong>',
						btns: [
							{id: 1, text: '다운로드', link: 'https://cdn.kcp.co.kr/design/download/NHN%20KCP%20PNG.zip'},
						]
					}
				]
			}
		}
	}
</script>
