<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- Container -->
		<Container>
			<!-- Location -->
			<Location v-bind:locations="locations"></Location>
			<!-- white 테마 적용 -->
			<!-- <Location v-bind:locations="locations" v-bind:theme="'white'"></Location> -->
			<!-- //Location -->

			<!-- title-h3 -->
			<title-h3>
				NHN KCP의 서비스 및 관련 업체의 <br>
				로고 이미지 ai, jpg 및 투명 배경인 png 파일을 <br>
				다운받으실 수 있습니다.
			</title-h3>
			<!-- //title-h3 -->

			<!-- text-p2 -->
			<text-p2>
				업체에서 로고 전달 시에는 design@kcp.co.kr 메일로 공유해 주시기 바랍니다.
			</text-p2>
			<!-- //text-p2 -->
		</Container>
		<!-- //Container -->

		<!-- list-logo -->
		<list-logo v-bind:listlogos="listlogos"></list-logo>
		<!-- //list-logo -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
	import ListLogo from "@/pages/Logo/ListLogo";

	export default {
		name: 'LogoEtc',
		components: {ListLogo},
		data: function(){
			return {
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'logo', text: this.$route.meta.location.logo},
					{id: 2, name: 'logoetc', text: this.$route.meta.location.logoetc}
				],
				listlogos: [
					{
						id: 1,
						imgs: [
							{id: 1, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 2, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 3, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 4, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 5, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 6, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 7, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 8, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 9, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 10, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 11, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
							{id: 12, filename: 'logo/img_payco_1_1.png', alt: 'NHN PAYCO'},
						],
						title: 'PAYCO',
						txt: '<span class="color-black">PAYCO의 경우 필요시 사용성에 맞춰 사용하되, 가이드가 엄격히 관리되고 있어 가이드를 필히 준수하여 사용해 주시기 바랍니다.</span><br>PAYCO CI, PAYCO BI, PAYCO 간편결제, PAYCO 오더, PAYCO Biz+, 캐릭터, 제휴사 표기 가이드',
						btns: false,
					},
					{
						id: 2,
						imgs: [
							{id: 1, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 2, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 3, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 4, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 5, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 6, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 7, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
							{id: 8, filename: 'logo/img_etc_1_1.png', alt: 'NHN'},
						],
						title: '기타 로고',
						txt: 'NHN, CHAPPAY, 솔비포스, NXPOS, 오더앤라이더, 셀프페이, VNCP, 핸디론',
						btns: false,
					},
				]
			}
		}
	}
</script>
