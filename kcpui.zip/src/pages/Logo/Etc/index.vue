<template>
	<div>로고 기타</div>
</template>