<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- Container -->
		<Container>
			<!-- Location -->
			<Location v-bind:locations="locations"></Location>
			<!-- white 테마 적용 -->
			<!-- <Location v-bind:locations="locations" v-bind:theme="'white'"></Location> -->
			<!-- //Location -->

			<!-- title-h3 -->
			<title-h3>
				타사의 로고는 임의로 수집하여 <br>
				배포 불가하여 업체에서 NHN KCP로 공유된 파일만 <br>
				업체에 전달 가능합니다.
			</title-h3>
			<!-- //title-h3 -->

			<!-- text-p2 -->
			<text-p2>
				로고 업데이트 시 이미지가 변경될 수 있습니다. 업체에서 로고 전달 시에는 design@kcp.co.kr 메일로 공유해 주시기 바랍니다.
			</text-p2>
			<!-- //text-p2 -->
		</Container>
		<!-- //Container -->

		<!-- list-logo -->
		<list-logo v-bind:listlogos="listlogos"></list-logo>
		<!-- //list-logo -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
	import ListLogo from "@/pages/Logo/ListLogo";

	export default {
		name: 'LogoFinance',
		components: {ListLogo},
		data: function(){
			return {
				locations: [
					// name: 라우터 네임드
					{id: 1, name: 'logo', text: '로고자료'},
					{id: 2, name: 'logofinance', text: '카드사/은행/간편결제'}
				],
				listlogos: [
					{
						id: 1,
						imgs: [
							{id: 1, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 2, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 3, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 4, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 5, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 6, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 7, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 8, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 9, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 10, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 11, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
							{id: 12, filename: 'logo/img_logo_1_1.png', alt: 'BC카드'},
						],
						title: '카드사 로고',
						txt: 'BC카드, KB 국민카드, 롯데카드, 삼성카드, 은련카드, 하나카드, 신한카드, 현대카드, NH농협카드, 우리카드, 광주카드, 전북카드',
						btns: [
							{id: 1, text: '전 카드사 다운로드', link: 'https://cdn.kcp.co.kr/design/download/전카드사로고.zip', theme: 'white'},
						]
					},
					{
						id: 2,
						imgs: [
							{id: 1, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 2, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 3, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 4, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 5, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 6, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 7, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 8, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 9, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 10, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 11, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 12, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 13, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 14, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 15, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
							{id: 16, filename: 'logo/img_logo_2_1.png', alt: 'BC카드'},
						],
						title: '은행 로고',
						txt: 'KB국민은행, KDB산업은행, MG새마을금고, 광주은행, IBK기업은행, 뱅크월렛, 수협은행, 신한은행, 신협, 한국시티은행, 우리은행, <br>유진 투자증권, 저축은행중앙회, 카카오뱅크, 케이뱅크, 하나은행',
						btns: false,
					},
					{
						id: 3,
						imgs: [
							{id: 1, filename: 'logo/img_logo_3_1.png', alt: 'BC카드'},
							{id: 2, filename: 'logo/img_logo_3_1.png', alt: 'BC카드'},
							{id: 3, filename: 'logo/img_logo_3_1.png', alt: 'BC카드'},
						],
						title: '간편결제 로고',
						txt: 'SSGPAY, 삼성페이, 네이버페이',
						btns: false,
					},
				]
			}
		}
	}
</script>
