<template>
	<div>로고 파이낸스</div>
</template>