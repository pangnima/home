<template>
	<h3 class="title-h3">
		<slot></slot>
	</h3>
</template>

<script>
	export default {
		name: 'TitleH3'
	}
</script>

<style scoped>
	.title-h3{margin-bottom:20px;font-size:32px;line-height:47px;color:#212121;font-weight:500;}
</style>