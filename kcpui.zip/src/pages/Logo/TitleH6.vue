<template>
	<h6 class="title-h6">
		<slot></slot>
	</h6>
</template>

<script>
	export default {
		name: 'TitleH6'
	}
</script>

<style scoped>
	.title-h6{margin-bottom:9px;font-size:20px;line-height:29px;color:#212121;font-weight:500;}
</style>