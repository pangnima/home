<template>
	<div class="location" v-bind:data-theme="theme">
		<router-link class="link" v-bind:to="{name: 'main'}">홈</router-link>

		<!-- 반복 -->
		<fragment v-for="location in locations" v-bind:key="location.id">
			<span class="icon-arrow">
				<svg xmlns="http://www.w3.org/2000/svg" width="7" height="12" viewBox="0 0 7 12">
					<g fill="none" fill-rule="evenodd">
						<g class="arrow-line">
							<g>
								<path d="M1 1L6 6 1 11" transform="translate(-81.000000, -98.000000) translate(81.000000, 98.000000)"/>
							</g>
						</g>
					</g>
				</svg>
			</span>
			<router-link class="link" v-bind:to="{name: location.name}">{{location.text}}</router-link>
		</fragment>
		<!-- //반복 -->
	</div>
</template>

<script>
	export default {
		name: 'Location',
		props: ['locations', 'theme']
	}
</script>

<style scoped>
	.location{margin-top:20px;margin-bottom:80px;font-size:14px;line-height:20px;}
	.location .link{color:#212121;opacity:0.6;}
	/* .location .link.router-link-exact-active{font-weight:500;opacity:1;} */
	.location .link:last-child{font-weight:500;opacity:1;}
	.location .icon-arrow{position:relative;top:1px;margin:0 8px;opacity:0.6;}
	.location .icon-arrow .arrow-line{stroke:#212121;}

	/* theme */
	.location[data-theme="white"] .link{color:#fff;}
	.location[data-theme="white"] .icon-arrow .arrow-line{stroke:#fff;}
</style>