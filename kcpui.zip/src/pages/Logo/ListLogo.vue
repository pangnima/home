<template>
	<fragment>
		<div class="list-logo" v-for="listlogo in listlogos" v-bind:key="listlogo.id">
			<div class="inner">
				<div class="top">
					<div class="txt-wrap">
						<p class="title">
							{{listlogo.title}}
						</p>
						<p class="txt" v-html="listlogo.txt"></p>
					</div>
					<div class="btn-wrap">
						<btn-download v-for="btn in listlogo.btns" v-bind:theme="btn.theme" v-bind:text="btn.text" v-bind:link="btn.link" v-bind:key="btn.id"></btn-download>

						<!-- swiper button -->
						<div v-bind:id="'swiper-button-prev-' + listlogo.id" class="swiper-button-prev" slot="button-prev">이전</div>
						<div v-bind:id="'swiper-button-next-' + listlogo.id" class="swiper-button-next" slot="button-next">다음</div>
						<!-- //swiper button -->
					</div>
				</div>
				<!-- swiper -->
				<!-- <swiper v-bind:options="swiperOptions"> -->
				<swiper v-bind:options="{
					watchOverflow: true,
					slidesPerView: 'auto',
					spaceBetween: 20,
					navigation: {
						prevEl: `#swiper-button-prev-${listlogo.id}`,
						nextEl: `#swiper-button-next-${listlogo.id}`,
					},
				}">
					<swiper-slide v-for="img in listlogo.imgs" v-bind:key="img.id">
						<div class="img-logo">
							<img :src="require(`@/assets/images/${img.filename}`)" :alt="img.alt">
						</div>
					</swiper-slide>
					<!-- swiper button -->
					<!-- <div class="swiper-button-prev" slot="button-prev">이전</div>
					<div class="swiper-button-next" slot="button-next">다음</div> -->
					<!-- //swiper button -->
				</swiper>
				<!-- //swiper -->
			</div>
		</div>
	</fragment>
</template>

<script>
	// vue2 swiper 사용
	// 참고: http://labs.brandi.co.kr/2021/08/02/choihs.html
	// ※ ie 대응으로 "swiper@4.4.1 vue-awesome-swiper@3.1.3" 사용
	// https://github.com/surmon-china/vue-awesome-swiper/tree/v3.1.3
	import { swiper, swiperSlide } from 'vue-awesome-swiper';
	import 'swiper/dist/css/swiper.css';

	import BtnDownload from "@/pages/Logo/BtnDownload";

	export default {
		name: 'ListLogo',
		components: {swiper, swiperSlide, BtnDownload},
		props: ['listlogos'],
		// data: function(){
		// 	return {
		// 		swiperOptions: {
		// 			watchOverflow: true,
		// 			slidesPerView: 'auto',
		// 			spaceBetween: 20,
		// 			navigation: {
		// 				prevEl: '.swiper-button-prev',
		// 				nextEl: '.swiper-button-next'
		// 			},
		// 		}
		// 	}
		// }
	}
</script>

<style scoped>
	.list-logo{margin-top:60px;overflow:hidden;}
	.list-logo > .inner{box-sizing:border-box;max-width:1440px;margin:0 auto;padding:0 60px;}
	.list-logo .top{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;}
	.list-logo .txt-wrap{flex:1;}
	.list-logo .title{font-size:22px;line-height:33px;color:#212121;font-weight:500;}
	.list-logo .txt{margin-top:9px;font-size:16px;line-height:26px;color:#7c7c7c;}
	.list-logo .txt >>> .color-black{color:#212121;}
	.list-logo .btn-wrap{display:flex;flex:0 0 auto;margin-bottom:5px;}
	.list-logo .btn-wrap .btn-download{margin-left:20px;}
	.list-logo .img-logo{position:relative;display:flex;width:100%;height:220px;background-color:#f2f2f2;justify-content:center;align-items:center;}
	.list-logo .img-logo > img{flex:0 1 auto;}
	.list-logo .swiper-container{margin-top:30px;overflow:visible;}
	.list-logo .swiper-container .swiper-slide{width:350px;}
	/* css 내에서 @경로 사용할때 접두사 '~' 붙여서 사용(webpack에서 해당모듈로 강제처리) */
	.list-logo .swiper-button-prev,
	.list-logo .swiper-button-next{position:static;width:50px;height:50px;margin:0;background:url('~@/assets/images/logo/btn_arrows.png') 0 0 no-repeat;font-size:0;line-height:0;color:transparent;}
	.list-logo .swiper-button-prev{margin-left:20px;}
	.list-logo .swiper-button-next{margin-left:10px;background-position:100% 0;}
	.list-logo .swiper-button-prev.swiper-button-disabled,
	.list-logo .swiper-button-next.swiper-button-disabled{opacity:0.4;}

	/* .list-logo .top{padding-right:130px;}
	.list-logo .swiper-button-prev,
	.list-logo .swiper-button-next{position:absolute;top:-85px;left:auto;right:0;}
	.list-logo .swiper-button-prev{right:60px;}
	.list-logo .swiper-button-next{} */
</style>

