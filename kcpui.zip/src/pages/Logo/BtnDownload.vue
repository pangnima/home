<template>
	<a :href="link" class="btn-download" v-bind:data-theme="theme">
		{{text}}
		<span class="icon-down">
			<svg xmlns="http://www.w3.org/2000/svg" width="13" height="11" viewBox="0 0 13 11">
				<g fill="none" fill-rule="evenodd">
					<path class="line-stroke" d="M5 4L8 7.5 5 11" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000) translate(6.500000, 7.500000) rotate(-270.000000) translate(-6.500000, -7.500000)"/>
					<path class="line-fill" d="M0 10H13V11H0z" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000)"/>
					<path class="line-fill" d="M2 4H11V5H2z" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000) translate(6.500000, 4.500000) rotate(-270.000000) translate(-6.500000, -4.500000)"/>
				</g>
			</svg>
		</span>
	</a>
</template>

<script>
	export default {
		name: 'BtnDownload',
		props: ['text', 'link', 'theme']
	}
</script>

<style scoped>
	.btn-download{display:inline-block;padding:12px 40px 14px 40px;background-color:#00c0f3;color:#fff;font-size:16px;line-height:24px;font-weight:500;}
	.btn-download + .btn-download{margin-left:20px;}
	.btn-download .icon-down{position:relative;top:-1px;margin-left:8px;}
	.btn-download .icon-down .line-stroke{stroke:#fff;}
	.btn-download .icon-down .line-fill{fill:#fff;}

	/* theme */
	/* .btn-download[data-theme="white"]{} */
</style>