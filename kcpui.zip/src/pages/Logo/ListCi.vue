<template>
	<fragment>
		<!-- key 값은 index 값으로 사용 안하기 -->
		<div class="list-ci" v-for="listci in listcis" v-bind:key="listci.id">
			<div class="ci">
				<!-- swiper -->
				<!-- <span class="txt-mark"><span>내부용</span></span> -->
				<swiper v-bind:options="swiperOptions">
					<!-- <swiper-slide>
						<div class="img-ci">
							<span class="txt-mark"><span>내부용</span></span>
							<img src="../../assets/images/img_ci_1.png" alt="NHN KCP CI">
						</div>
					</swiper-slide>
					<swiper-slide>
						<div class="img-ci">
							<span class="txt-mark"><span>내부용</span></span>
							<img src="../../assets/images/img_ci_1.png" alt="NHN KCP CI">
						</div>
					</swiper-slide>
					<swiper-slide>
						<div class="img-ci">
							<span class="txt-mark"><span>내부용</span></span>
							<img src="../../assets/images/img_ci_1.png" alt="NHN KCP CI">
						</div>
					</swiper-slide>
					<swiper-slide>
						<div class="img-ci">
							<span class="txt-mark"><span>내부용</span></span>
							<img src="../../assets/images/img_ci_1.png" alt="NHN KCP CI">
						</div>
					</swiper-slide> -->

					<swiper-slide v-for="img in listci.imgs" v-bind:key="img.id">
						<div class="img-ci">
							<!-- v-if v-show 차이 알기 -->
							<span class="txt-mark" v-if="img.mark"><span>{{img.mark}}</span></span>

							<!-- 이미지 경로 처리 -->
							<!-- <img :src="'../../assets/images/' + img.filename" :alt="img.alt"> -->
							<img :src="require(`@/assets/images/${img.filename}`)" :alt="img.alt">
						</div>
					</swiper-slide>

					<!-- pagination -->
					<div class="swiper-pagination" slot="pagination"></div>
				</swiper>
				<!-- //swiper -->
			</div>
			<div class="info">
				<!-- <p class="title">NHN KCP CI</p> -->
				<!-- <p class="title">
					<slot name="title"></slot>
				</p> -->
				<p class="title">
					{{listci.title}}
				</p>
				<!-- <p class="txt">
					해당 가이드는 NHN과 협의가 이뤄진 CI 가이드로 외부 업체에서 <br>
					NHN KCP 로고 요청 시 사용 바랍니다. <br>
					가이드 외 디자인의 변경된 사용은 불가합니다. <br>
					<strong>파일 형식 : ai, jpg</strong>
				</p> -->
				<!-- <p class="txt">
					<slot name="txt"></slot>
				</p> -->
				<!-- 문자열 html으로 처리 -->
				<p class="txt" v-html="listci.txt"></p>

				<p class="btn-wrap">
					<!-- <a :href="listci.downloadlink" class="btn-download">
						다운로드
						<span class="icon-down">
							<svg xmlns="http://www.w3.org/2000/svg" width="13" height="11" viewBox="0 0 13 11">
								<g fill="none" fill-rule="evenodd">
									<path class="line-stroke" d="M5 4L8 7.5 5 11" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000) translate(6.500000, 7.500000) rotate(-270.000000) translate(-6.500000, -7.500000)"/>
									<path class="line-fill" d="M0 10H13V11H0z" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000)"/>
									<path class="line-fill" d="M2 4H11V5H2z" transform="translate(-858.000000, -826.000000) translate(751.000000, 808.000000) translate(107.000000, 18.000000) translate(6.500000, 4.500000) rotate(-270.000000) translate(-6.500000, -4.500000)"/>
								</g>
							</svg>
						</span>
					</a> -->
					<!-- <fragment v-for="btn in listci.btns" v-bind:key="btn.id">
						<btn-download v-bind:text="btn.text" v-bind:link="btn.link"></btn-download>
					</fragment> -->
					<btn-download v-for="btn in listci.btns" v-bind:text="btn.text" v-bind:link="btn.link" v-bind:key="btn.id"></btn-download>
				</p>
			</div>
		</div>
	</fragment>
</template>

<script>
	// vue2 swiper 사용
	// 참고: http://labs.brandi.co.kr/2021/08/02/choihs.html
	// ※ ie 대응으로 "swiper@4.4.1 vue-awesome-swiper@3.1.3" 사용
	// https://github.com/surmon-china/vue-awesome-swiper/tree/v3.1.3
	import { swiper, swiperSlide } from 'vue-awesome-swiper';
	import 'swiper/dist/css/swiper.css';

	import BtnDownload from "@/pages/Logo/BtnDownload";

	export default {
		name: 'ListCi',
		components: {swiper, swiperSlide, BtnDownload},
		props: ['listcis'],
		data: function(){
			return {
				swiperOptions: {
					watchOverflow: true,
					pagination: {
						el: '.swiper-pagination',
						type: 'bullets',
						clickable: true
					},
				}
			}
		}
	}
</script>

<style scoped>
	.list-ci{margin-top:30px;display:flex;flex-wrap:wrap;}
	.list-ci .ci{position:relative;flex:1 0 0;width:630px;min-width:400px;margin-right:60px;}
	.list-ci .info{flex:1 0 0;width:630px;min-width:0;padding-top:33px;border-top:1px solid #212121;}
	.list-ci .img-ci{position:relative;display:flex;width:100%;height:400px;background-color:#f2f2f2;justify-content:center;align-items:center;}
	.list-ci .img-ci > img{flex:0 1 auto;}
	.list-ci .txt-mark{display:flex;position:absolute;top:30px;left:30px;width:80px;height:80px;border-radius:50%;background-color:#212121;color:#fff;font-size:16px;line-height:24px;justify-content:center;align-items:center;z-index:100;}
	.list-ci .title{margin-bottom:15px;font-size:26px;line-height:38px;color:#212121;font-weight:500;}
	.list-ci .txt{font-size:16px;line-height:28px;color:#7c7c7c;}
	.list-ci .btn-wrap{margin-top:40px;}
	.list-ci .swiper-pagination{bottom:40px;font-size:0;line-height:0;}
	/* 이슈: 동적으로 생성되는 요소는 scoped 적용 안됨 ('>>>' 깊은 추적 선택자사용으로 해결) */
	.list-ci >>> .swiper-pagination-bullet{width:10px;height:10px;margin:0 5px;background-color:#ccc;opacity:1;}
	.list-ci >>> .swiper-pagination-bullet-active{background-color:#212121;}
</style>

