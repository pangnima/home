<template>
	<p class="text-p2">
		<slot></slot>
	</p>
</template>

<script>
	export default {
		name: 'TextP2'
	}
</script>

<style scoped>
	.text-p2{margin-bottom:100px;font-size:16px;line-height:28px;color:#212121;}
</style>