<template>
	<div>프로젝트 뷰</div>
</template>