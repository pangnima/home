<template>
	<div>디자인 템플릿</div>
</template>