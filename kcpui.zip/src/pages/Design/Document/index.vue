<template>
	<div>디자인 문서양식</div>
</template>