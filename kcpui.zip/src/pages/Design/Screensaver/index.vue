<template>
	<div>디자인 스크린세이버</div>
</template>