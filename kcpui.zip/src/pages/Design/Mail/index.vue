<template>
	<div>디자인 메일폼</div>
</template>