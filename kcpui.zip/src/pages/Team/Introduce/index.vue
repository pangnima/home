<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- nav -->
		<TheNav>
			<a href="#">홈</a> <a href="#">NHN KCP UI</a> <a href="#" class="active">NHN KCP UI</a>
		</TheNav>
		<!-- //nav -->

		<!-- Visual -->
		<VisualTop>
			<swiper class="slide-wrap" :options="swiperOption">
				<swiper-slide class="slide bg-1">
					<Container>
						<p class="txt-1">더욱 가치있는 UI/UX를 만들기 위해 <br>우리는 늘 끊임없이 변화하고 있습니다.</p>
						<p class="txt-2">We are constantly changing</p>
						<p class="txt-3">최신 IT 기술이 빨리 실용화되고 결제 시장 서비스를 더 의미 있고 가치 있게 만들기 위해 <br>늘 변화에 적극적으로 대비하고 있습니다.</p>
					</Container>
				</swiper-slide>
				<swiper-slide class="slide bg-2">
					<Container>
						<p class="txt-1">사용성과 디지털 기술의 융합을 통한 <br>유용한 크리에이티브를 디자인합니다.</p>
						<p class="txt-3">디자인은 심미적인 것만 요구하는 것이 아닌, 시장성/사용자와 상호작용을 바탕으로 완성됩니다. <br>불확실성 속에 우리는 늘 트렌트를 연구하고 통찰하여 제시합니다. <br>- Design Part -</p>
					</Container>
				</swiper-slide>
				<swiper-slide class="slide bg-3">
					<Container>
						<p class="txt-1">조금 더 간단하게, 조금 더 빠르게, <br>조금 더 단단하게 최적화를 구현합니다.</p>
						<p class="txt-3">IT 기술 성장과 시대적인 변화에 빠르게 적응할 수 있도록 만전의 준비를 하며 <br>front-end 영역 지식 확대를 통해 폭넓고 싶은 협업을 통한 시너지를 냅니다. <br>- Publishing Part -</p>
					</Container>
				</swiper-slide>
				<div class="swiper-pagination" slot="pagination"></div>
				<div class="swiper-button-prev" slot="button-prev"></div>
				<div class="swiper-button-next" slot="button-next"></div>
			</swiper>
		</VisualTop>
		<!-- // Visual -->

		<!-- Container -->
		<Container class="content">
			<!-- UI Team Process -->
			<p class="tit-type-1">UI Team Process</p>
			<ul class="list-type-1">
				<li>
					<p class="tit-1">1</p>
					<p class="tit-2">타사 분석 및 요건 검토</p>
					<ul class="list-type-2">
						<li>UI Benchmarking</li>
						<li>Publishing 요건 검토<br>
						(구축 지원범위, jQuery 버전,<br>
						접근성 지원 등)</li>
					</ul>
				</li>
				<li>
					<p class="tit-1">2</p>
					<p class="tit-2">UI/UX Design</p>
					<ul class="list-type-2">
						<li>디자인 시안</li>
						<li>시안 확정 및 Develop</li>
						<li>전체 UI/UX Design</li>
						<li>Zeplin Guide 퍼블리싱파트 전달</li>
					</ul>
				</li>
				<li>
					<p class="tit-1">3</p>
					<p class="tit-2">Web Publishing</p>
					<ul class="list-type-2">
						<li>웹 리소스 구조화</li>
						<li>HTML+CSS+JavaScript / jQuery</li>
						<li>Markup</li>
						<li>UI Test</li>
					</ul>
				</li>
				<li>
					<p class="tit-1">4</p>
					<p class="tit-2">UI QA</p>
					<ul class="list-type-2">
						<li>UI QA (UI팀 + 요청부서)</li>
						<li>Markup 수정</li>
					</ul>
				</li>
			</ul>

			<!-- Design Part Skills -->
			<p class="tit-type-1">Design Part Skills</p>
			<p class="txt-type-1">UI/UX Design, Illustration, Editorial design, Motion graphics, Prototype design guide</p>
			<ul class="list-type-3">
				<li><img src="../../../assets/images/introduce/ci-icon-ps.png" alt="Photoshop"> <span>Photoshop</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-xd.png" alt="XD"> <span>XD</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-sketch.png" alt="Sketch"> <span>Sketch</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-ai.png" alt="Illustrator"> <span>Illustrator</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-ae.png" alt="After Effects"> <span>After Effects</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-zeplin.png" alt="Zeplin"> <span>Zeplin</span></li>
			</ul>
			
			<!-- Publishing Part Skills -->
			<p class="tit-type-1">Publishing Part Skills</p>
			<p class="txt-type-1">웹표준, Cross Browsing, Cross Device, 적응형/반응형, 시맨틱태그, CSS pre-processor(SASS)</p>
			<ul class="list-type-3 pd-2">
				<li><img src="../../../assets/images/introduce/ci-icon-html.png" alt="HTML"><span>HTML</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-css.png" alt="CSS"><span>CSS</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-js.png" alt="Javascript"><span>Javascript</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-jquery.png" alt="jQuery"><span>jQuery</span></li>
				<li><img src="../../../assets/images/introduce/ci-icon-vue.png" alt="Vue"><span>Vue(진행중)</span></li>
			</ul>

			<!-- CSS 방향 -->
			<p class="tit-type-1">CSS 방향</p>
			<p class="txt-type-1">코드의 재사용성 및 확장성, 범용성, 유지 보수에 용이함을 중시된 OOCSS 방법론으로 구조 설계합니다.</p>
			<ul class="list-type-4">
				<li>
					<div class="css-box-1 bg-1">
						<p class="txt-1">SMACSS</p>
						<p class="txt-2">Scalable and Modular Architecture for CSS</p>
					</div>
					<ul class="list-type-5">
						<li>CSS에 대한 확장형 모듈식 구조</li>
						<li>기본(Base), 레이아웃(Layout), <br>모듈(Module), 상태(State), 테마(Theme)로 나뉨</li>
					</ul>
				</li>
				<li>
					<div class="css-box-1 bg-2">
						<p class="txt-1">BEM</p>
						<p class="txt-2">Block Element Modifier</p>
					</div>
					<ul class="list-type-5">
						<li>블록(Block), 요소(Element), 상태(Modifier)로 <br>구분하여 클래스 이름을 작성하는 방법</li>
					</ul>
				</li>
				<li>
					<div class="css-box-1 bg-3">
						<p class="txt-1">OOCSS</p>
						<p class="txt-2">Object Oriented CSS</p>
					</div>
					<ul class="list-type-5">
						<li>CSS를 모듈 방식으로 코딩하여 중복을 최소화하며 캡슐화함</li>
						<li>코드 양을 줄일 수 있음</li>
					</ul>
				</li>
			</ul>
		</Container>
		<!-- //Container -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
// swiper
import 'swiper/dist/css/swiper.css';
import { swiper, swiperSlide } from 'vue-awesome-swiper';
import TheNav from '@/pages/Team/TheNav';
import VisualTop from '@/pages/Team/VisualTop';

export default {
	components: {
		TheNav,
		VisualTop,
		swiper,
		swiperSlide,
	},
	data() {
		return {
			swiperOption: {
				slidesPerView: 1,
				spaceBetween: 0,
				loop: true,
				autoplay: {delay:4000},
				pagination: {
					el: '.swiper-pagination',
					type: 'fraction',
					clickable: true
				},
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev'
				}
			}
		}
	}
}
</script>

<style scoped>
.slide-wrap{height:790px;}
.slide-wrap .slide{padding:0 60px;box-sizing:border-box;}
.slide-wrap .slide .container{height:100%;}
.slide-wrap .slide.bg-1 .container{background:url(../../../assets/images/introduce/swiper-bg-1.png) right center no-repeat;}
.slide-wrap .slide.bg-2 .container{background:url(../../../assets/images/introduce/swiper-bg-2.png) 86% center no-repeat;}
.slide-wrap .slide.bg-3 .container{background:url(../../../assets/images/introduce/swiper-bg-3.png) right center no-repeat;}
.slide-wrap .slide .txt-1{padding-top:251px;font-size:52px;color:#fff;line-height:74px;font-weight:500;}
.slide-wrap .slide .txt-2{padding-top:20px;font-size:22px;color:#fff;line-height:33px;font-weight:500;}
.slide-wrap .slide .txt-3{padding-top:48px;font-size:18px;color:#fff;line-height:24px;font-weight:500;}
.slide-wrap >>> .swiper-pagination-fraction{bottom:60px !important;left:60px !important;width:auto !important;font-size:0;}
.slide-wrap >>> .swiper-pagination-fraction:after{content:'';clear:both;display:block;position:absolute;top:10px;left:14px;width:36px;height:1px;background:#fff;}
.slide-wrap >>> .swiper-pagination-current{padding-right:23px;font-size:16px;color:#fff;font-weight:500;}
.slide-wrap >>> .swiper-pagination-total{padding-left:23px;font-size:16px;color:#fff;font-weight:500;}
.swiper-button-next{top:auto;right:60px;bottom:60px;left:auto;width:50px;height:50px;background:url(../../../assets/images/introduce/btn-arrow-next.png) 0 0 no-repeat;}
.swiper-button-prev{top:auto;right:120px;bottom:60px;left:auto;width:50px;height:50px;background:url(../../../assets/images/introduce/btn-arrow-prev.png) 0 0 no-repeat;}
.swiper-button-next:after, .swiper-button-prev:after{display:none;}
.container.content{padding-top:112px!important;}
.visual-wrap + .container.content{padding-top:0!important;}
.tit-type-1{padding:100px 0 10px;font-size:20px;color:#212121;font-weight:500;}
.tit-type-1:first-child{padding-top:60px;}
.txt-type-1{font-size:16px;color:#535353;line-height:28px;}
.list-type-1{padding-top:20px;}
.list-type-1:after{content:'';clear:both;display:block;}
.list-type-1 > li{float:left;width:260px;margin-left:93px;}
.list-type-1 > li:first-child{margin-left:0px;}
.list-type-1 .tit-1{padding-bottom:20px;margin-bottom:20px;border-bottom:1px solid #212121;font-size:20px;color:#212121;font-weight:bold;}
.list-type-1 .tit-2{padding-bottom:20px;font-size:22px;color:#212121;font-weight:500;}
.list-type-2 > li{position:relative;padding-left:13px;margin-top:8px;font-size:14px;color:#535353;line-height:24px;}
.list-type-2 > li:before{content:'・';clear:both;display:block;position:absolute;top:0;left:0;}
.list-type-2 > li:first-child{margin-top:0;}
.list-type-3{padding-top:39px;}
.list-type-3:after{content:'';clear:both;display:block;}
.list-type-3 > li{float:left;margin-left:60px;text-align:center;}
.list-type-3 > li:first-child{margin-left:0;}
.list-type-3 > li > img{display:block;margin:0 auto;}
.list-type-3 > li > span{display:block;padding-top:10px;font-size:14px;color:#7c7c7c;line-height:28px;}
.list-type-3.pd-2{padding-top:50px;}
.list-type-3.pd-2 > li{margin-left:40px;}
.list-type-3.pd-2 > li:first-child{margin-left:0;}
.list-type-4{padding-top:30px;}
.list-type-4:after{content:'';clear:both;display:block;}
.list-type-4 > li{float:left;margin-left:40px;}
.list-type-4 > li:first-child{margin-left:0;}
.css-box-1{width:413px;height:230px;padding:30px;box-sizing:border-box;background:#000;}
.css-box-1.bg-1{background:url(../../../assets/images/introduce/css-thumbnail-01.png) 0 0 no-repeat;}
.css-box-1.bg-2{background:url(../../../assets/images/introduce/css-thumbnail-02.png) 0 0 no-repeat;}
.css-box-1.bg-3{background:url(../../../assets/images/introduce/css-thumbnail-03.png) 0 0 no-repeat;}
.css-box-1 .txt-1{font-size:26px;color:#fff;line-height:38px;font-weight:500;}
.css-box-1 .txt-2{padding-top:2px;font-size:14px;color:#fff;line-height:28px;}
.list-type-5{padding-top:21px;margin-top:20px;border-top:1px solid #212121;}
.list-type-5 > li{position:relative;padding-left:13px;margin-top:8px;font-size:14px;color:#7c7c7c;line-height:28px;}
.list-type-5 > li:before{content:'・';clear:both;display:block;position:absolute;top:0;left:0;}
.list-type-5 > li:first-child{margin-top:0;}
</style>