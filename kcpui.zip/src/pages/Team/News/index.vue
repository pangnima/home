<template>
	<div>팀 소식</div>
</template>