<template>
	<div class="visual-wrap">
		<slot></slot>
	</div>
</template>

<script>
	export default {
		name: 'VisualTop'
	}
</script>

<style scoped>
.visual-wrap{display:block;position:relative;background:#00c0f3;}
.visual-wrap .container{position:relative;}
</style>
