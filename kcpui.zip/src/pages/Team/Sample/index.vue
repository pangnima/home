<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- nav -->
		<TheNavBlack>
			<a href="#">홈</a> <a href="#" class="active">샘플</a>
		</TheNavBlack>
		<!-- //nav -->

		<!-- Container -->
		<Container>
			<Title1>타이틀텍스트1</Title1>
			<Title2>타이틀텍스트2</Title2>
			<SubText1>서브설명텍스트1</SubText1>
			<SubText2>서브설명텍스트2</SubText2>
			
		</Container>
		<!-- //Container -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
import TheNavBlack from '@/pages/Guide/TheNavBlack';
import Title1 from "@/pages/Guide/Title1";
import SubText1 from "@/pages/Guide/SubText1";
import Title2 from "@/pages/Guide/Title2";
import SubText2 from "@/pages/Guide/SubText2";

export default {
	components: {
		TheNavBlack,
		Title1,
		Title2,
		SubText1,
		SubText2
	}
}
</script>

<style scoped>


.tit-type-2{color:var(--blue);}
.txt-type-1{padding-bottom:var(--gap-xs);}
</style>
