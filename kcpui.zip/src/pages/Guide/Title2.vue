<template>
	<p class="tit-type-2">
		<slot></slot>
	</p>
</template>

<script>
	export default {
		name: 'Title1'
	}
</script>

<style scoped>
.tit-type-2{font-size:22px;color:#212121;font-weight:500;}
</style>
