<template>
	<fragment>
		<!-- header -->
		<TheHeader></TheHeader>
		<!-- //header -->

		<!-- nav -->
		<TheNavBlack>
			<a href="#">홈</a> <a href="#" class="active">가이드</a>
		</TheNavBlack>
		<!-- //nav -->

		<!-- Container -->
		<Container>
			<Title1>NHN KCP UI 팀에서 배포하는 <br>가이드를 다운 받으실 수 있습니다.</Title1>
			<SubText1>외부 업체에서 디자인 진행 시 가이드를 꼭 준수할 수 있도록 안내 바랍니다.</SubText1>
			<ul class="list-type-1">
				<li>
					<div class="img-box">
						<img src="@/assets/images/guide/thumbnail-01.png" alt="">
						<a href="#"><span class="btn-download">파일 다운로드</span></a>
					</div>
					<p class="txt-1">NHNKCP Design Guide</p>
					<p class="txt-2">일괄된 NHN KCP의 아이덴티티를 유지하기 위해 규정으로 로고에 대한 <br>최소 공간, 크기, 변형, 컬러, 폰트 등으로 구성되어 있습니다.</p>
				</li>
				<li>
					<div class="img-box">
						<img src="@/assets/images/guide/thumbnail-02.png" alt="">
						<a href="#"><span class="btn-download">파일 다운로드</span></a>
					</div>
					<p class="txt-1">가맹점 자체 간편결제</p>
					<p class="txt-2">NHN KCP 가맹점 자체 간편결제 구현을 위한 CSS 및 디자인 변경 방법에 관해 설명된 <br>가이드입니다. 필요시 가맹점에서 직접 수정 후 UI팀에서 소스를 검토하고 있습니다.</p>
				</li>
				<li>
					<div class="img-box">
						<img src="@/assets/images/guide/thumbnail-03.png" alt="">
						<a href="#"><span class="btn-download">파일 다운로드</span></a>
					</div>
					<p class="txt-1">Web, Mobile 결제창 배너 가이드</p>
					<p class="txt-2">NHN KCP 웹표준 결제창과 모바일 결제창의 배너 가이드입니다. <br>Web 결제창 하단 좌측, Mobile 결제창 하단 영역으로 최대 4개까지 롤링됩니다.</p>
				</li>
				<li>
					<div class="img-box">
						<img src="@/assets/images/guide/thumbnail-04.png" alt="">
						<a href="#"><span class="btn-download">파일 다운로드</span></a>
					</div>
					<p class="txt-1">NHN KCP 홈페이지 배너 가이드</p>
					<p class="txt-2">NHN KCP 홈페이지 배너 가이드입니다. 메인 고정 배너, 롤링 배너 영역과 <br>서브 결제내역 조회 상단 배너 영역으로 구성되어 있습니다.</p>
				</li>
			</ul>
		</Container>
		<!-- //Container -->

		<!-- footer -->
		<TheFooter></TheFooter>
		<!-- //footer -->
	</fragment>
</template>

<script>
import TheNavBlack from '@/pages/Guide/TheNavBlack';
import Title1 from "@/pages/Guide/Title1";
import SubText1 from "@/pages/Guide/SubText1";

export default {
	components: {
		TheNavBlack,
		Title1,
		SubText1
	}
}
</script>

<style scoped>
.list-type-1:after{content:'';clear:both;display:block;}
.list-type-1 > li{float:left;width:630px;min-height:510px;margin:0 0 60px 60px;}
.list-type-1 > li:nth-child(2n+1){margin-left:0;}
.list-type-1 > li .img-box{position:relative;}
.list-type-1 > li .img-box > img{width:100%;}
.list-type-1 > li .img-box > a{display:block;position:absolute;top:0;left:0;width:100%;height:100%;}
.list-type-1 > li .img-box > a:after{content:'';clear:both;display:block;position:absolute;top:0;left:0;width:100%;height:100%;background:#000;opacity:0;}
.list-type-1 > li .img-box > a:hover:after{opacity:0.7;transition:0.3s;}
.list-type-1 > li .img-box .btn-download{opacity:0;position:absolute;bottom:20px;right:20px;padding-right:33px;background:url(~@/assets/images/guide/btn_download.png) right center no-repeat;font-size:14px;color:#fff;line-height:26px;font-weight:500;text-decoration:underline;}
.list-type-1 > li .img-box > a:hover .btn-download{z-index:1;opacity:1;transition:0.3s;}
.list-type-1 > li .txt-1{padding-top:30px;font-size:22px;color:#212121;font-weight:500;}
.list-type-1 > li .txt-2{padding-top:10px;font-size:16px;color:#7c7c7c;}
</style>
