<template>
	<p class="tit-type-1">
		<slot></slot>
	</p>
</template>

<script>
	export default {
		name: 'Title1'
	}
</script>

<style scoped>
.tit-type-1{font-size:32px;color:#212121;font-weight:500;}
</style>
