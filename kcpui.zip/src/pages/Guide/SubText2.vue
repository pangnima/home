<template>
	<p class="txt-type-2">
		<slot></slot>
	</p>
</template>

<script>
	export default {
		name: 'SubText1'
	}
</script>

<style scoped>
.txt-type-2{padding:0 0 10px;font-size:12px;color:#212121;}
</style>
