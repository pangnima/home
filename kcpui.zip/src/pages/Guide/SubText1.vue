<template>
	<p class="txt-type-1">
		<slot></slot>
	</p>
</template>

<script>
	export default {
		name: 'SubText1'
	}
</script>

<style scoped>
.txt-type-1{padding:20px 0 100px;font-size:16px;color:#212121;}
</style>
