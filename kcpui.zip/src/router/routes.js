// 추후 고려: Vue 번들 크기 줄이기(초기 로딩시간 줄임)
// https://velog.io/@kyusung/reduce-vue-bundle-size

// 적용 완료: @ 경로 사용(상대 경로명이 길어질때 유용)
// https://www.imkh.dev/vue-alias-path/

// 메인
import Main from '@/pages/Main';
// 팀
import TeamIntroduce from '@/pages/Team/Introduce';
// 로고
import LogoKcp from '@/pages/Logo/Kcp';
import LogoFinance from '@/pages/Logo/Finance';
import LogoEtc from '@/pages/Logo/Etc';
// 가이드
import Guide from '@/pages/Guide';
// 디자인
import DesignUi from '@/pages/Design/Ui';
import DesignDocument from '@/pages/Design/Document';
import DesignMail from '@/pages/Design/Mail';
import DesignTemplate from '@/pages/Design/Template';
// 마크업
import MarkupGuide from '@/pages/Markup/Guide';
import MarkupAccessibility from '@/pages/Markup/Accessibility';
import MarkupAdblock from '@/pages/Markup/Adblock';
import MarkupAdblockClass from '@/pages/Markup/Adblock/Class';
import MarkupAdblockId from '@/pages/Markup/Adblock/Id';
import MarkupWebfont from '@/pages/Markup/Webfont';
import MarkupWebfontNormal from '@/pages/Markup/Webfont/Normal';
import MarkupWebfontLight from '@/pages/Markup/Webfont/Light';
// 프로젝트
import Project from '@/pages/Project';
import ProjectView from '@/pages/Project/View';
// 에러
import Error from '@/pages/Error';

// route location
const pageNames = {
	// 메인
	main : '메인',
	// 팀
	team : '팀',
	teamintroduce : 'NHN KCP UI',
	// logo
	logo: '로고자료',
	logokcp: 'NHN KCP',
	logofinance: '카드사/은행/간편결제',
	logoetc: '기타 로고',
	// 가이드
	guide : '가이드',
	// 디자인자료
	design : '디자인자료',
	designui : '결제창 화면 UI',
	designdocument : '문서양식',
	designmail : '공식 메일 폼',
	designtemplate : '현수막, X배너 템플릿',
	// 마크업
	markup : '마크업 시 참고',
	markupguide : '마크업 가이드',
	markupaccessibility : '웹결제창 접근성',
	markupadblock : '애드블럭 차단 소스',
	markupwebfont : '디자인 폰트 경량화',
	// 프로젝트
	project : '프로젝트',
	projectview : '프로젝트',
};

// routes
const routes = [
	/*
		[path(url) 네이밍]
		소문자 한단어로 명명(권장)
		두단어이상은 "-" 으로 연결(kebab-case)
	*/

	// 메인
	{path: '/', redirect: '/main'}, /* redirect */
	{path: '/main', name: 'main', component: Main, meta: {location: pageNames}},
	// 팀
	{path: '/team', name: 'team', redirect: '/team/introduce', meta: {location: pageNames}}, /* redirect */
	{path: '/team/introduce', name: 'teamintroduce', component: TeamIntroduce, meta: {location: pageNames}},
	// 로고
	{path: '/logo', name: 'logo', redirect: '/logo/kcp', meta: {location: pageNames}}, /* redirect */
	{path: '/logo/kcp', name: 'logokcp', component: LogoKcp, meta: {location: pageNames}},
	{path: '/logo/finance', name: 'logofinance', component: LogoFinance, meta: {location: pageNames}},
	{path: '/logo/etc', name: 'logoetc', component: LogoEtc, meta: {location: pageNames}},
	// 가이드
	{path: '/guide', name: 'guide', component: Guide, meta: {location: pageNames}},
	// 디자인
	{path: '/design', name: 'design', redirect: '/design/ui', meta: {location: pageNames}}, /* redirect */
	{path: '/design/ui', name: 'designui', component: DesignUi, meta: {location: pageNames}},
	{path: '/design/document', name: 'designdocument', component: DesignDocument, meta: {location: pageNames}},
	{path: '/design/mail', name: 'designmail', component: DesignMail, meta: {location: pageNames}},
	{path: '/design/template', name: 'designtemplate', component: DesignTemplate, meta: {location: pageNames}},
	// 마크업
	{path: '/markup', name: 'markup', redirect: '/markup/guide', meta: {location: pageNames}}, /* redirect */
	{path: '/markup/guide', name: 'markupguide', component: MarkupGuide, meta: {location: pageNames}},
	{path: '/markup/accessibility', name: 'markupaccessibility', component: MarkupAccessibility, meta: {location: pageNames}},
	{path: '/markup/adblock', name: 'markupadblock', component: MarkupAdblock,meta: {location: pageNames}, redirect: '/markup/adblock/class', /* redirect */
		children: [
			{path: 'class', name: 'markupadblockclass', component: MarkupAdblockClass, meta: {location: pageNames}},
			{path: 'id', name: 'markupadblockid', component: MarkupAdblockId, meta: {location: pageNames}}
		]
	},
	{path: '/markup/webfont', name: 'markupwebfont', component: MarkupWebfont, meta: {location: pageNames}, redirect: '/markup/webfont/normal', /* redirect */
		children: [
			{path: 'normal', name: 'markupwebfontnormal', component: MarkupWebfontNormal, meta: {location: pageNames}},
			{path: 'light', name: 'markupwebfontlight', component: MarkupWebfontLight, meta: {location: pageNames}}
		]
	},
	// 프로젝트
	{path: '/project', name: 'project', component: Project, meta: {location: pageNames}},
	{path: '/project/view', name: 'projectview', component: ProjectView, meta: {location: pageNames}},
	// 에러
	{path: '*', name: 'error', component: Error},
];

export default routes;