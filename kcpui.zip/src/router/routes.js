// 추후 고려: Vue 번들 크기 줄이기(초기 로딩시간 줄임)
// https://velog.io/@kyusung/reduce-vue-bundle-size

// 적용 완료: @ 경로 사용(상대 경로명이 길어질때 유용)
// https://www.imkh.dev/vue-alias-path/

// 메인
import Main from '@/pages/Main';
// 팀
import TeamIntroduce from '@/pages/Team/Introduce';
// 로고
import LogoKcp from '@/pages/Logo/Kcp';
import LogoFinance from '@/pages/Logo/Finance';
import LogoEtc from '@/pages/Logo/Etc';
// 가이드
import Guide from '@/pages/Guide';
// 디자인
import DesignUi from '@/pages/Design/Ui';
import DesignDocument from '@/pages/Design/Document';
import DesignMail from '@/pages/Design/Mail';
import DesignTemplate from '@/pages/Design/Template';
// 마크업
import MarkupGuide from '@/pages/Markup/Guide';
import MarkupAccessibility from '@/pages/Markup/Accessibility';
import MarkupAdblock from '@/pages/Markup/Adblock';
import MarkupAdblockClass from '@/pages/Markup/Adblock/Class';
import MarkupAdblockId from '@/pages/Markup/Adblock/Id';
import MarkupWebfont from '@/pages/Markup/Webfont';
import MarkupWebfontNormal from '@/pages/Markup/Webfont/Normal';
import MarkupWebfontLight from '@/pages/Markup/Webfont/Light';
// 프로젝트
import Project from '@/pages/Project';
import ProjectView from '@/pages/Project/View';
// 에러
import Error from '@/pages/Error';

const routes = [
	/*
		[path(url) 네이밍]
		소문자 한단어로 명명(권장)
		두단어이상은 "-" 으로 연결(kebab-case)
	*/

	// 메인
	{path: '/', redirect: '/main'}, /* redirect */
	{path: '/main', name: 'main', component: Main},
	// 팀
	{path: '/team', name: 'team', redirect: '/team/introduce'}, /* redirect */
	{path: '/team/introduce', name: 'teamintroduce', component: TeamIntroduce},
	// 로고
	{path: '/logo', name: 'logo', redirect: '/logo/kcp'}, /* redirect */
	{path: '/logo/kcp', name: 'logokcp', component: LogoKcp},
	{path: '/logo/finance', name: 'logofinance', component: LogoFinance},
	{path: '/logo/etc', name: 'logoetc', component: LogoEtc},
	// 가이드
	{path: '/guide', name: 'guide', component: Guide},
	// 디자인
	{path: '/design', name: 'design', redirect: '/design/ui'}, /* redirect */
	{path: '/design/ui', name: 'designui', component: DesignUi},
	{path: '/design/document', name: 'designdocument', component: DesignDocument},
	{path: '/design/mail', name: 'designmail', component: DesignMail},
	{path: '/design/template', name: 'designtemplate', component: DesignTemplate},
	// 마크업
	{path: '/markup', name: 'markup', redirect: '/markup/guide'}, /* redirect */
	{path: '/markup/guide', name: 'markupguide', component: MarkupGuide},
	{path: '/markup/accessibility', name: 'markupaccessibility', component: MarkupAccessibility},
	{path: '/markup/adblock', name: 'markupadblock', component: MarkupAdblock, redirect: '/markup/adblock/class', /* redirect */
		children: [
			{path: 'class', name: 'markupadblockclass', component: MarkupAdblockClass},
			{path: 'id', name: 'markupadblockid', component: MarkupAdblockId}
		]
	},
	{path: '/markup/webfont', name: 'markupwebfont', component: MarkupWebfont, redirect: '/markup/webfont/normal', /* redirect */
		children: [
			{path: 'normal', name: 'markupwebfontnormal', component: MarkupWebfontNormal},
			{path: 'light', name: 'markupwebfontlight', component: MarkupWebfontLight}
		]
	},
	// 프로젝트
	{path: '/project', name: 'project', component: Project},
	{path: '/project/view', name: 'projectview', component: ProjectView},
	// 에러
	{path: '*', name: 'error', component: Error},
];

export default routes;