<script>
	/*
		styled component 설명
		https://github.com/styled-components/vue-styled-components
	*/
	import styled from 'vue-styled-components';

	/*
		css 사용 기본 옵션 (필요에 따라 추가)
	*/
	const typographyProps = {
		margin:String,
		padding:String,
		fontSize :String,
		lineHeight:String,
		color:String,
		fontWeight:String,
		fontFamily:String,
		type:String,
	};

	/*
		타입설정별 기본 값 설정
	*/
	const resultProp = (props) =>{
		switch(props.as){
			case 'h1' :
				props.fontSize = props.fontSize || '72px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'h2' :
				props.fontSize = props.fontSize || '52px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'h3' :
				props.fontSize = props.fontSize || '32px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'h4' :
				props.fontSize = props.fontSize || '26px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'h5' :
				props.fontSize = props.fontSize || '22px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'h6' :
				props.fontSize = props.fontSize || '20px';
				props.fontWeight = props.fontWeight || '500';
				break;
			case 'p' :
				switch (props.type) {
					case 'p1':
						props.fontSize = props.fontSize || '18px';
						break;
					case 'p2':
						props.fontSize = props.fontSize || '16px';
						break;
					case 'desc':
						props.fontSize = props.fontSize || '14px';
						props.color = props.color || '#7c7c7c';
						break;
				}
				break;
		}
	}

	/*
		기본 값이 있을경우 resultProp함수 사용 후 리턴
		기본 값이 없는경우 props를 바로 리턴
	*/
	const Typography = styled('p', typographyProps)`
		margin:${props => props.margin};
		padding:${props => props.padding};
		font-size:${props => {
			resultProp(props)
			return props.fontSize;
		}};
		line-height:${props => props.lineHeight};
		color: ${props => {
			resultProp(props)
			return props.color;
		}};
		font-weight: ${props => {
			resultProp(props)
			return props.fontWeight;
		}};
		font-family: ${props => props.fontFamily};
	`;

	export default Typography;
</script>