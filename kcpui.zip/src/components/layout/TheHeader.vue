<template>
	<div id="header" 
		:class="{isActive:isActive}"
		v-on:mouseover="onMouseover"
		v-on:mouseleave="onMouseleave"
		>
		<Container>
			<!-- 로고 & 메인 -->
			<h1 class="logo"><router-link class="link" to="/main"><img src="../../assets/images/icon-logo.png" alt="LOGO"></router-link></h1>
			<nav class="gnb">
				<ul>
					<!-- 팀 -->
					<li><router-link class="link" to="/team">NHN KCP UI</router-link></li>
					<!-- 로고 -->
					<li>
						<router-link class="link" to="/logo">로고자료</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/logo/kcp">NHN KCP</router-link>
							</li>
							<li>
								<router-link class="link" to="/logo/finance">카드사/은행/간편결제</router-link>
							</li>
							<li>
								<router-link class="link" to="/logo/etc">기타 로고</router-link>
							</li>
						</ul>
					</li>
					<li>
						<!-- 가이드 -->
						<router-link class="link" to="/guide">가이드</router-link>
					</li>
					<li>
						<!-- 디자인 -->
						<router-link class="link" to="/design">디자인자료</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/design/ui">결제창 화면 UI</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/document">문서양식</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/mail">공식 메일폼</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/template">현수막, X배너 템플릿</router-link>
							</li>
						</ul>
					</li>
					<li>
						<!-- 마크업 -->
						<router-link class="link" to="/markup">마크업 시 참고</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/markup/guide">마크업 가이드</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/accessibility">웹결제창 접근성</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/adblock">애드블록 차단 소스</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/webfont">디자인 폰트 경량화</router-link>
							</li>
						</ul>
					</li>
					<li>
						<!-- 프로젝트 -->
						<router-link class="link" to="/project">프로젝트</router-link>
					</li>
				</ul>
			</nav>
		</Container>
	</div>
</template>

<script>
	import Container from './Container'
	export default {
		components: { Container },
		name: 'TheHeader',
		data : function () {
			return {
				isActive : false
			}
		},
		methods: {
			onMouseover: function(e){
				console.log(e.target.nextElementSibling.classList )
				// if(e.target.nextElementSibling.classList = null){
				// 	return
				// } else{
				// 	console.log(e.target.nextElementSibling.classList)
				// }
				// if(e.target.classList == 'link'){
				// 	this.isActive = true
				// } else{
				// 	this.isActive = false
				// }
			},    
			onMouseleave: function(){
				// console.log("TEST@@")
				this.isActive = false
			}
		}
	}

	// new Vue({
	// 	// el:'#header',
	// 	methods : {
	// 		doMouseOver : () =>{
	// 			console.log('test');
	// 		}
	// 	}
	// })
</script>

<style scoped>
#header{position:relative;border-bottom:solid 1px #212121;;}
#header::before{content:"";position:absolute;top:100%;left:0;right:0;background:#eee;height:0;transition:height .5s;}
#header.isActive::before{height:300px;}
#header .container{display:flex;font-size:16px;align-items:center;justify-content:space-between;}
/* 메인메뉴 */
.gnb{flex:1;}
.gnb a{color:#212121;}
.gnb > ul{display:flex;height:72px;line-height:28px;font-size:16px;justify-content:end;}
.gnb > ul > li{display:flex;position:relative;padding-left:40px;align-items:center;}
.gnb > ul > li a{display:flex;height:100%;;align-items:center;}
.gnb > ul > li .link::after{content:"";display:block;width:6px;height:6px;margin-left:5px;border-right:solid 1px #000;border-bottom:solid 1px #000;transform:rotate(45deg);}
.gnb > ul > li .link:only-child::after{display:none;}
/* 하위뎁스 */
.gnb [class^=depth]{display:none;position:absolute;top:100%;left:0;padding-top:20px;padding-left:40px;white-space:nowrap;}
/* 메인메뉴 오버  */
.gnb ul li:hover > [class^=depth]{display:block;position:absolute;top:100%;}
/* .gnb > ul > li > a.router-link-active::after{content:"";display:block;background:#000;width:100%;height:1px;} */
/* .gnb > ul > li:hover > a::after{content:"";display:block;background:#000;width:100%;height:1px;} */





</style>
