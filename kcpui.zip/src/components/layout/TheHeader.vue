<template>
	<!--
		* 헤더 타입 별 class 추가
		type-1 : 로고 & 텍스트 컬러 흰색
	-->
	<header id="header" :class="{isActive:isActive,isFixed:isFixed}" v-on:scroll="onScroll">
		<Container>
			<!-- 로고 & 메인 -->
			<h1 class="logo">
				<router-link class="link" to="/main">
					<LogoImg></LogoImg>
				</router-link>
			</h1>
			<nav class="gnb">
				<ul>
					<!-- 팀 -->
					<li><router-link class="link" to="/team">{{$route.meta.location.teamintroduce}}</router-link></li>
					<!-- 로고 -->
					<li class="depth" v-on:mouseover="onMouseover" v-on:mouseleave="onMouseleave">
						<router-link class="link" to="/logo">{{$route.meta.location.logo}}</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/logo/kcp">{{$route.meta.location.logokcp}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/logo/finance">{{$route.meta.location.logofinance}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/logo/etc">{{$route.meta.location.logoetc}}</router-link>
							</li>
						</ul>
					</li>
					<li>
						<!-- 가이드 -->
						<router-link class="link" to="/guide">{{$route.meta.location.guide}}</router-link>
					</li>
					<li class="depth" v-on:mouseover="onMouseover" v-on:mouseleave="onMouseleave">
						<!-- 디자인 -->
						<router-link class="link" to="/design">{{$route.meta.location.design}}</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/design/ui">{{$route.meta.location.designui}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/document">{{$route.meta.location.designdocument}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/mail">{{$route.meta.location.designmail}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/design/template">{{$route.meta.location.designtemplate}}</router-link>
							</li>
						</ul>
					</li>
					<li class="depth" v-on:mouseover="onMouseover" v-on:mouseleave="onMouseleave">
						<!-- 마크업 -->
						<router-link class="link" to="/markup">{{$route.meta.location.markup}}</router-link>
						<ul class="depth-2">
							<li>
								<router-link class="link" to="/markup/guide">{{$route.meta.location.markupguide}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/accessibility">{{$route.meta.location.markupaccessibility}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/adblock">{{$route.meta.location.markupadblock}}</router-link>
							</li>
							<li>
								<router-link class="link" to="/markup/webfont">{{$route.meta.location.markupwebfont}}</router-link>
							</li>
						</ul>
					</li>
					<li>
						<!-- 프로젝트 -->
						<router-link class="link" to="/project">{{$route.meta.location.project}}</router-link>
					</li>
				</ul>
			</nav>
		</Container>
	</header>
</template>

<script>
	import Container from './Container';
	import LogoImg from '../logo.vue'
	export default {
		components: {Container,LogoImg},
		name: 'TheHeader',
		data : function () {
			return {
				isActive : false,
				isFixed : false,
			}
		},
		created : function(){
			window.addEventListener('scroll', this.onScroll)
		},
		methods: {
			onMouseover: function(){
				this.isActive = true
			},    
			onMouseleave: function(){
				this.isActive = false
			},
			onScroll : function(){ 
				if (window.scrollY > 10 ){
					this.isFixed = true
				} else {
					this.isFixed = false
				}
			}
		}
	}
</script>

<style scoped>
/* 헤더 기본 값 */
#header{position:fixed;top:0;width:100%;border-bottom:solid 1px #212121;z-index:3000;transition:background-color .5s;}
#header .container{display:flex;align-items:center;justify-content:space-between;}
#header::before{content:"";position:absolute;top:100%;left:0;right:0;background:#fff;height:0;border-top:solid 1px #000;transition:height .25s;}
#header >>> .logo svg g{transform:fill .5s;fill:#000;}
/* 헤더 타입 : 화이트*/
#header.type-1::before{border-color:#fff;}
#header.type-1 >>> .logo svg g{fill:#fff;}
#header.type-1 .gnb > ul > li > a{color:#fff;}
#header.type-1 .gnb > ul > li:hover > a,
#header.type-1 .gnb > ul > li > a.router-link-active{border-color:#fff;}
#header.type-1 .gnb > ul > li .link::after{border-color:#fff;}
/* 헤더 메뉴 오버 */
#header.isActive::before{height:167px;}
/* 헤더 스크롤 시 픽스 */
#header.isFixed{background:#fff;}
#header.type-1.isFixed .gnb a, #header.isFixed .gnb a{color:#212121}
#header.isFixed::before{border-color:#000;}
#header.isFixed .gnb > ul > li > a.router-link-active{border-color:#000;}
#header.isFixed .gnb > ul > li .link::after{border-color:#000;}
#header.isFixed >>> .logo svg g{fill:#000;}
/* 메인메뉴 */
.gnb{flex:1;}
.gnb a{color:#212121;transform:color 1s;}
.gnb > ul{display:flex;height:72px;line-height:28px;font-size:16px;justify-content:flex-end;}
.gnb > ul > li{display:flex;position:relative;padding-left:40px;align-items:center;}
.gnb > ul > li:hover > a,
.gnb > ul > li > a.router-link-active{border-bottom:solid 1px #000;}
.gnb > ul > li a{display:flex;align-items:center;}
.gnb > ul > li .link::after{content:"";display:block;width:3px;height:3px;margin-left:5px;border-right:solid 1px #000;border-bottom:solid 1px #000;transform:rotate(45deg);}
.gnb > ul > li .link:only-child::after{display:none;}
/* 메인메뉴 뎁스 */
.gnb [class^=depth] [class^=depth]{display:none;position:absolute;top:100%;left:0;padding-top:20px;padding-left:40px;white-space:nowrap;}
.gnb [class^=depth] [class^=depth] li{margin-top:5px;}
.gnb [class^=depth] [class^=depth] li:first-child{margin-top:0;}
/* 메인메뉴 오버  */
.gnb ul li:hover > [class^=depth]{display:block;position:absolute;top:100%;z-index:3000;}
</style>
