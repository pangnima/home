<template>
	<footer id="footer">
		<Container>
			<div class="footer-desc">
				<h2>NHN KCP UI</h2>
				<p>
					NHN KCP UI is a collaboration led by designers and publishers in the IT center.<br>
					We are constantly striving to advance design and technology.
				</p>
			</div>
			<div class="footer-link">
				<dl>
					<dt>Contect</dt>
					<dd>design@kcp.co.kr</dd>
				</dl>
				<dl>
					<dt>Markup list site (대외비)</dt>
					<dd>http://cdn.kcp.co.kr/design/design_MDS.html</dd>
				</dl>
				<p>Copyrightⓒ NHN KCP Corp. All Rights Reserved.</p>
			</div>
		</Container>
	</footer>
</template>

<script>
	import Container from './Container'
	export default {
		components: { Container },
		name: 'TheFooter'
	}
</script>

<style scoped>
#footer{padding-top:100px;}
#footer .container{max-width:1320px; display:flex;padding:35px 0 40px;border-top:solid 1px #e1e1e1;color:#7c7c7c;justify-content:space-between;}
#footer .container .footer-desc{flex:1;}
#footer .container .footer-desc h2{font-size:14px;}
#footer .container .footer-desc p{margin-top:10px;}
#footer .container .footer-link dl{display:flex;}
#footer .container .footer-link dl{margin-bottom:10px;}
#footer .container .footer-link dl dt{margin-right:10px;font-size:14px;font-weight:bold;}
#footer .container .footer-link p{font-size:12px;}

</style>
