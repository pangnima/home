<template>
	<div id="footer">
		<Container>
			<div class="footer-desc">
				<h2>NHN KCP UI</h2>
				<p>
					NHN KCP UI is a collaboration led by designers and publishers in the IT center.<br>
					We are constantly striving to advance design and technology.
				</p>
			</div>
			<div class="footer-link">
				<dl>
					<dt>Contect</dt>
					<dd>design@kcp.co.kr</dd>
				</dl>
				<dl>
					<dt>Markup list site (대외비)</dt>
					<dd>http://cdn.kcp.co.kr/design/design_MDS.html</dd>
				</dl>
				<p>Copyrightⓒ NHN KCP Corp. All Rights Reserved.</p>
			</div>
		</Container>
	</div>
</template>

<script>
	import Container from './Container'
	export default {
		components: { Container },
		name: 'TheFooter'
	}
</script>

<style scoped>
#footer .container{display:flex;color:#7c7c7c;justify-content:space-between; padding:35px 60px 40px;}
#footer .container .footer-desc{flex:1;}
#footer .container .footer-desc h2{font-size:14px;}
#footer .container .footer-desc p{margin-top:10px;}
#footer .container .footer-link dl{display:flex;}
#footer .container .footer-link dl{margin-bottom:10px;}
#footer .container .footer-link dl dt{margin-right:10px;font-size:14px;font-weight:bold;}
#footer .container .footer-link p {font-size:12px}
</style>
