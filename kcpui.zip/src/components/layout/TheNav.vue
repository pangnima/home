<template>
	<div class="nav-wrap">
		<div class="inner">
			<div class="nav">
				<slot></slot>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'TheNav'
	}
</script>

<style scoped>
.nav-wrap{position:absolute;top:93px;left:0;width:100%;z-index:10;}
.nav-wrap .inner{position:relative;box-sizing:border-box;width:1440px;padding:0 60px;margin:0 auto;}
.nav a{display:inline-block;position:relative;opacity:0.6;padding-left:23px;font-size:14px;color:#fff;font-weight:500;}
.nav a:first-child{padding-left:0;}
.nav a:after{content:'';clear:both;display:block;position:absolute;top:6px;right:-15px;width:7px;height:7px;border-top:1px solid #fff;border-right:1px solid #fff;transform:rotate(45deg);}
.nav a:last-child:after{display:none;}
.nav a.active{opacity:1;}
</style>
