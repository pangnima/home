<template>
	<div class="container">
		<slot></slot>
	</div>
</template>

<script>
	export default {
		name: 'Container'
	}
</script>

<style scoped>
	.container{box-sizing:border-box;max-width:1440px;margin:0 auto;padding:0 60px;}
</style>
